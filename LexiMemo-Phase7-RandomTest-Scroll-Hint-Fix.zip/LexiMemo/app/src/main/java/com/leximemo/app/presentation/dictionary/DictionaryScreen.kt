package com.leximemo.app.presentation.dictionary

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.leximemo.app.data.local.entity.WordEntity
import com.leximemo.app.presentation.components.WordImage

private enum class WordFilter(val label: String) {
    ALL("All"), MEMORIZED("Memorized"), HINT("Hint Needed"), FORGOT("Forgot"), FAVORITES("Favorites")
}

private enum class WordSort(val label: String) {
    NEWEST("Newest first"), OLDEST("Oldest first"), A_TO_Z("A–Z"), Z_TO_A("Z–A")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DictionaryScreen(
    onEditWord: (Long) -> Unit,
    initialFavoritesOnly: Boolean = false,
    viewModel: DictionaryViewModel = viewModel()
) {
    val words by viewModel.words.collectAsState()
    var search by remember { mutableStateOf("") }
    var filter by remember(initialFavoritesOnly) { mutableStateOf(if (initialFavoritesOnly) WordFilter.FAVORITES else WordFilter.ALL) }
    var sort by remember { mutableStateOf(WordSort.NEWEST) }
    var sortExpanded by remember { mutableStateOf(false) }
    var selectedWord by remember { mutableStateOf<WordEntity?>(null) }
    var deleteCandidate by remember { mutableStateOf<WordEntity?>(null) }

    val visibleWords = remember(words, search, filter, sort) {
        words.asSequence()
            .filter { word ->
                val matchesSearch = search.isBlank() ||
                    word.englishWord.contains(search.trim(), ignoreCase = true) ||
                    word.englishMeaning.contains(search.trim(), ignoreCase = true) ||
                    word.banglaMeaning.contains(search.trim(), ignoreCase = true)
                val matchesFilter = when (filter) {
                    WordFilter.ALL -> true
                    WordFilter.MEMORIZED -> word.latestRating == "MEMORIZED"
                    WordFilter.HINT -> word.latestRating == "HINT_NEEDED"
                    WordFilter.FORGOT -> word.latestRating == "FORGOT"
                    WordFilter.FAVORITES -> word.isFavorite
                }
                matchesSearch && matchesFilter
            }
            .let { sequence ->
                when (sort) {
                    WordSort.NEWEST -> sequence.sortedWith(compareByDescending<WordEntity> { it.addedDate }.thenByDescending { it.id })
                    WordSort.OLDEST -> sequence.sortedWith(compareBy<WordEntity> { it.addedDate }.thenBy { it.id })
                    WordSort.A_TO_Z -> sequence.sortedBy { it.englishWord.lowercase() }
                    WordSort.Z_TO_A -> sequence.sortedByDescending { it.englishWord.lowercase() }
                }
            }.toList()
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Dictionary", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("${words.size} words in your vocabulary", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Search English or Bangla meaning") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            shape = RoundedCornerShape(14.dp)
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${visibleWords.size} results", modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelLarge)
            Box {
                TextButton(onClick = { sortExpanded = true }) { Text("Sort: ${sort.label}") }
                DropdownMenu(expanded = sortExpanded, onDismissRequest = { sortExpanded = false }) {
                    WordSort.values().forEach { option ->
                        DropdownMenuItem(text = { Text(option.label) }, onClick = { sort = option; sortExpanded = false })
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            WordFilter.values().take(3).forEach { option ->
                FilterChip(selected = filter == option, onClick = { filter = option }, label = { Text(option.label) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            WordFilter.values().drop(3).forEach { option ->
                FilterChip(selected = filter == option, onClick = { filter = option }, label = { Text(option.label) })
            }
        }
        if (visibleWords.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(if (words.isEmpty()) "No words yet. Add your first word." else "No matching words found.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(visibleWords, key = { it.id }) { word ->
                    WordListItem(
                        word = word,
                        onClick = { selectedWord = word },
                        onFavorite = { viewModel.toggleFavorite(word) }
                    )
                }
            }
        }
    }

    selectedWord?.let { word ->
        AlertDialog(
            onDismissRequest = { selectedWord = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(word.englishWord, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    IconButton(onClick = { viewModel.toggleFavorite(word) }) {
                        Icon(if (word.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = "Toggle favorite", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    WordImage(imagePath = word.imagePath, word = word.englishWord)
                    Text(word.englishMeaning, style = MaterialTheme.typography.bodyLarge)
                    Text(word.banglaMeaning, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                    word.partOfSpeech?.let { Text("Part of Speech: $it") }
                    word.synonym?.let { Text("Synonyms: $it") }
                    word.antonym?.let { Text("Antonyms: $it") }
                    Text("Example: ${word.sentence1}")
                    word.sentence2?.let { Text("Example 2: $it") }
                    Text("Status: ${word.latestRating?.replace('_', ' ') ?: "Not reviewed"}", color = MaterialTheme.colorScheme.primary)
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedWord = null; onEditWord(word.id) }) { Text("Edit") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { selectedWord = null; deleteCandidate = word }) { Text("Delete") }
                    TextButton(onClick = { selectedWord = null }) { Text("Close") }
                }
            }
        )
    }

    deleteCandidate?.let { word ->
        AlertDialog(
            onDismissRequest = { deleteCandidate = null },
            title = { Text("Delete word?") },
            text = { Text("Delete '${word.englishWord}' and its related revision records?") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteWord(word) { deleteCandidate = null }
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleteCandidate = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun WordListItem(word: WordEntity, onClick: () -> Unit, onFavorite: () -> Unit) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            WordImage(imagePath = word.imagePath, word = word.englishWord, modifier = Modifier.width(76.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(word.englishWord, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(word.banglaMeaning, style = MaterialTheme.typography.bodyMedium)
                Text(
                    word.latestRating?.replace('_', ' ') ?: "Not reviewed",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onFavorite) {
                Icon(
                    if (word.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = if (word.isFavorite) "Remove favorite" else "Add favorite",
                    tint = if (word.isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
