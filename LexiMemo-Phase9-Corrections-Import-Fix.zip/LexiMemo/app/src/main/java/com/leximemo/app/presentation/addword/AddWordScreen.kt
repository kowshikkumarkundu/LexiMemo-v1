package com.leximemo.app.presentation.addword

import android.net.Uri
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.content.Context
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.leximemo.app.data.local.entity.WordEntity

@Composable
fun AddWordScreen(wordId: Long? = null, viewModel: AddWordViewModel = viewModel()) {
    val words by viewModel.words.collectAsState()
    var englishWord by remember { mutableStateOf("") }
    var englishMeaning by remember { mutableStateOf("") }
    var banglaMeaning by remember { mutableStateOf("") }
    var sentence1 by remember { mutableStateOf("") }
    var sentence2 by remember { mutableStateOf("") }
    var partOfSpeech by remember { mutableStateOf("") }
    var synonym by remember { mutableStateOf("") }
    var antonym by remember { mutableStateOf("") }
    var selectedImage by remember { mutableStateOf<Uri?>(null) }
    var imagePreview by remember { mutableStateOf<Bitmap?>(null) }
    val context = androidx.compose.ui.platform.LocalContext.current
    var showDelete by remember { mutableStateOf<WordEntity?>(null) }
    var editingWord by remember { mutableStateOf<WordEntity?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        selectedImage = uri
        if (uri == null) {
            message = "No image selected."
        }
    }

    LaunchedEffect(selectedImage, editingWord?.imagePath) {
        imagePreview = withContext(Dispatchers.IO) {
            try {
                when {
                    selectedImage != null -> decodePreview(context, selectedImage!!)
                    editingWord?.imagePath != null -> decodePreview(File(editingWord!!.imagePath!!))
                    else -> null
                }
            } catch (_: Exception) { null }
        }
    }

    LaunchedEffect(wordId, words) {
        if (wordId != null && editingWord?.id != wordId) {
            words.firstOrNull { it.id == wordId }?.let { word ->
                editingWord = word
                englishWord = word.englishWord
                englishMeaning = word.englishMeaning
                banglaMeaning = word.banglaMeaning
                sentence1 = word.sentence1
                sentence2 = word.sentence2.orEmpty()
                partOfSpeech = word.partOfSpeech.orEmpty()
                synonym = word.synonym.orEmpty()
                antonym = word.antonym.orEmpty()
                selectedImage = null
            }
        }
    }

    LaunchedEffect(viewModel.message) {
        viewModel.message?.let { message = it; viewModel.consumeMessage() }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(if (editingWord == null) "Add New Word" else "Edit Word", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
            Text("Fields marked * are required", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item { FormField("English Word *", englishWord, { englishWord = it }, "e.g. Abundant") }
        item { FormField("English Meaning *", englishMeaning, { englishMeaning = it }, "Meaning in English", minLines = 2) }
        item { FormField("Bangla Meaning *", banglaMeaning, { banglaMeaning = it }, "বাংলা অর্থ", minLines = 2) }
        item { FormField("Example Sentence 1 *", sentence1, { sentence1 = it }, "Write an example sentence", minLines = 2) }
        item { FormField("Example Sentence 2", sentence2, { sentence2 = it }, "Optional second sentence", minLines = 2) }
        item { FormField("Part of Speech", partOfSpeech, { partOfSpeech = it }, "e.g. Noun, Verb, Adjective") }
        item { FormField("Synonym", synonym, { synonym = it }, "Optional") }
        item { FormField("Antonym", antonym, { antonym = it }, "Optional") }
        item {
            OutlinedCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Word Image (Optional)", style = MaterialTheme.typography.titleMedium)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                            Icon(Icons.Default.Image, contentDescription = null)
                            Spacer(Modifier.width(6.dp)); Text(if (selectedImage == null) "Choose Image" else "Change Image")
                        }
                        if (selectedImage != null) Text("New image selected", style = MaterialTheme.typography.bodySmall)
                        else if (editingWord?.imagePath != null) Text("Current image will be kept", style = MaterialTheme.typography.bodySmall)
                    }
                    imagePreview?.let { bitmap ->
                        Image(
                            bitmap = bitmap.asImageBitmap(),
                            contentDescription = "Selected word image preview",
                            modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp),
                            contentScale = ContentScale.Fit
                        )
                    }
                    Text(
                        if (selectedImage != null) "Image selected. It will be copied to app storage when you save."
                        else "Maximum image size: 5 MB. Choose an image from your gallery.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        item {
            Button(
                modifier = Modifier.fillMaxWidth().height(52.dp),
                enabled = !viewModel.isSaving,
                onClick = {
                    viewModel.save(englishWord, englishMeaning, banglaMeaning, sentence1, sentence2, partOfSpeech, synonym, antonym, selectedImage, editingWord) { success ->
                        if (success) {
                            englishWord = ""; englishMeaning = ""; banglaMeaning = ""; sentence1 = ""
                            sentence2 = ""; partOfSpeech = ""; synonym = ""; antonym = ""; selectedImage = null; editingWord = null
                        }
                    }
                }
            ) { if (viewModel.isSaving) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) else Text(if (editingWord == null) "Save Word" else "Update Word") }
            if (editingWord != null) TextButton(onClick = {
                editingWord = null; englishWord = ""; englishMeaning = ""; banglaMeaning = ""; sentence1 = ""
                sentence2 = ""; partOfSpeech = ""; synonym = ""; antonym = ""; selectedImage = null
            }) { Text("Cancel Edit") }
            message?.let {
                Text(it, color = if (it.contains("success", true) || it.contains("deleted", true)) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            }
        }

    }

    showDelete?.let { word ->
        AlertDialog(
            onDismissRequest = { showDelete = null },
            title = { Text("Delete word?") },
            text = { Text("Delete ‘${word.englishWord}’ and its related revision records?") },
            confirmButton = { TextButton(onClick = { viewModel.delete(word); showDelete = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { showDelete = null }) { Text("Cancel") } }
        )
    }
}

private suspend fun decodePreview(context: Context, uri: Uri): Bitmap? =
    withContext(Dispatchers.IO) {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, bounds)
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@withContext null
        var sample = 1
        while (bounds.outWidth / sample > 1200 || bounds.outHeight / sample > 1200) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, options)
        }
    }

private fun decodePreview(file: File): Bitmap? {
    if (!file.exists()) return null
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    file.inputStream().use { BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / sample > 1200 || bounds.outHeight / sample > 1200) sample *= 2
    val options = BitmapFactory.Options().apply { inSampleSize = sample }
    return file.inputStream().use { BitmapFactory.decodeStream(it, null, options) }
}

@Composable
private fun FormField(label: String, value: String, onValueChange: (String) -> Unit, placeholder: String, minLines: Int = 1) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(label, style = MaterialTheme.typography.labelLarge)
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text(placeholder) },
            minLines = minLines,
            shape = RoundedCornerShape(12.dp),
            singleLine = minLines == 1
        )
    }
}

@Composable
private fun WordRow(word: WordEntity, onEdit: () -> Unit, onDelete: () -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(word.englishWord, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(word.banglaMeaning, style = MaterialTheme.typography.bodyMedium)
                Text(word.englishMeaning, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                TextButton(onClick = onEdit) { Text("Edit") }
                IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Delete ${word.englishWord}") }
            }
        }
    }
}
