package com.leximemo.app.presentation.dashboard

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun DashboardScreen(onAddWord: () -> Unit, viewModel: DashboardViewModel = viewModel()) {
    val dateText = viewModel.today.format(DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.ENGLISH))
    val dayText = viewModel.today.format(DateTimeFormatter.ofPattern("EEEE", Locale.ENGLISH))
    val activity by viewModel.activity.collectAsState()
    val activities by viewModel.activities.collectAsState()
    val defaultTarget by viewModel.target.collectAsState()
    val totalWords by viewModel.totalWords.collectAsState()
    val dueWords by viewModel.dueWords.collectAsState()
    val added = activity?.addedWordCount ?: 0
    // Once the first word is added, that day's target remains a fixed snapshot.
    val target = activity?.targetForDay ?: defaultTarget
    val remaining = (target - added).coerceAtLeast(0)
    val streak = remember(activities, viewModel.today) {
        viewModel.currentStreak(activities, viewModel.today)
    }
    var showTargetDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("My Vocabulary", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Learn • Practice • Remember", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("$dayText, $dateText", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        }

        ElevatedCard(
            modifier = Modifier.fillMaxWidth().clickable { showTargetDialog = true },
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Daily Target", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    Text("Change", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
                }
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("$added", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(" / $target words", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.weight(1f))
                    Text("${((added.toFloat() / target.coerceAtLeast(1)) * 100).toInt().coerceAtMost(100)}%", style = MaterialTheme.typography.titleMedium)
                }
                LinearProgressIndicator(
                    progress = { (added.toFloat() / target.coerceAtLeast(1)).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(9.dp)
                )
                Text(
                    when {
                        remaining == 0 -> "Daily target completed. Great work!"
                        remaining == 1 -> "Just 1 more word to reach your target."
                        else -> "$remaining words remaining today"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            SummaryCard("Current Streak", "$streak ${if (streak == 1) "day" else "days"}", "One-day grace included", Modifier.weight(1f))
            SummaryCard("Total Words", totalWords.toString(), "In your dictionary", Modifier.weight(1f))
        }

        Text("Quick Overview", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            SummaryCard("Today's Practice", "$added words", "Added today", Modifier.weight(1f))
            SummaryCard("Today's Revision", "$dueWords due", "Pending review words", Modifier.weight(1f))
        }

        ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    if (added >= target) "You reached today's goal!" else "Build your vocabulary every day",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    if (added >= target) "Your daily target is complete. Keep the momentum going."
                    else "Add a few useful words today and make steady progress.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(onClick = onAddWord, modifier = Modifier.fillMaxWidth()) {
                    Text(if (totalWords == 0) "Add Your First Word" else "Add Word")
                }
            }
        }
        Text(
            "Your progress is stored on this device. Daily target changes apply to new daily records; an existing day's target stays unchanged.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    if (showTargetDialog) {
        DailyTargetDialog(
            currentTarget = defaultTarget,
            onDismiss = { showTargetDialog = false },
            onSave = { value ->
                viewModel.updateTarget(value)
                showTargetDialog = false
            }
        )
    }
}

@Composable
private fun SummaryCard(title: String, value: String, subtitle: String, modifier: Modifier = Modifier) {
    OutlinedCard(modifier = modifier, shape = RoundedCornerShape(18.dp)) {
        Column(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun DailyTargetDialog(currentTarget: Int, onDismiss: () -> Unit, onSave: (Int) -> Unit) {
    val presets = listOf(5, 10, 15, 20, 25, 30)
    var selected by remember(currentTarget) { mutableIntStateOf(if (currentTarget in presets) currentTarget else -1) }
    var custom by remember(currentTarget) { mutableStateOf(if (currentTarget !in presets) currentTarget.toString() else "") }
    val customValue = custom.toIntOrNull()
    val chosen = if (selected == -1) customValue else selected
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Set Daily Target") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Choose how many new words you want to add each day.")
                presets.forEach { value ->
                    Row(
                        modifier = Modifier.fillMaxWidth().clickable { selected = value },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = selected == value, onClick = { selected = value })
                        Text("$value words")
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = selected == -1, onClick = { selected = -1 })
                    OutlinedTextField(
                        value = custom,
                        onValueChange = { custom = it.filter(Char::isDigit).take(3); selected = -1 },
                        label = { Text("Custom (1–100)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                if (selected == -1 && (customValue == null || customValue !in 1..100)) {
                    Text("Enter a number from 1 to 100.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { chosen?.takeIf { it in 1..100 }?.let(onSave) }, enabled = chosen != null && chosen in 1..100) {
                Text("Save")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
