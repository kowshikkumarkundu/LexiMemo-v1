package com.leximemo.app.presentation.practice

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import com.leximemo.app.data.local.entity.WordEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun PracticeScreen(viewModel: PracticeViewModel = viewModel()) {
    val words by viewModel.todayWords.collectAsState()
    var currentIndex by remember { mutableIntStateOf(0) }
    var answerVisible by remember { mutableStateOf(false) }
    var hintVisible by remember { mutableStateOf(false) }
    val viewedIds = remember { mutableStateListOf<Long>() }

    LaunchedEffect(words.map { it.id }) {
        viewedIds.retainAll(words.map { it.id }.toSet())
        answerVisible = false
        hintVisible = false
        if (words.isEmpty()) currentIndex = 0
        else if (currentIndex > words.lastIndex) currentIndex = words.lastIndex
    }

    val currentWord = words.getOrNull(currentIndex)
    val isComplete = words.isNotEmpty() && words.all { it.id in viewedIds }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Today's Practice", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "Review the words you added today. This practice can be repeated anytime.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        if (words.isEmpty()) {
            EmptyPracticeState()
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Card ${currentIndex + 1} of ${words.size}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                Text("${words.count { it.id in viewedIds }}/${words.size} viewed", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            }
            LinearProgressIndicator(
                progress = { (words.count { it.id in viewedIds }.toFloat() / words.size.coerceAtLeast(1)).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth()
            )

            currentWord?.let { word ->
                PracticeFlashcard(
                    word = word,
                    answerVisible = answerVisible,
                    hintVisible = hintVisible,
                    onToggleHint = { hintVisible = !hintVisible },
                    onToggleAnswer = {
                        answerVisible = !answerVisible
                        if (answerVisible && word.id !in viewedIds) viewedIds.add(word.id)
                    }
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = { currentIndex--; answerVisible = false; hintVisible = false },
                    enabled = currentIndex > 0,
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(5.dp)); Text("Previous", style = MaterialTheme.typography.labelLarge)
                }
                Button(
                    onClick = { currentIndex++; answerVisible = false; hintVisible = false },
                    enabled = currentIndex < words.lastIndex,
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Text("Next", style = MaterialTheme.typography.labelLarge); Spacer(Modifier.width(5.dp))
                    Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
                }
            }

            if (isComplete) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Practice completed!", fontWeight = FontWeight.Bold)
                            Text("You viewed all ${words.size} words added today.", style = MaterialTheme.typography.bodyMedium)
                        }
                        TextButton(onClick = { currentIndex = 0; answerVisible = false; hintVisible = false; viewedIds.clear() }) {
                            Icon(Icons.Default.Replay, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text("Again")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyPracticeState() {
    ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
            Text("No words added today", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text("Add a new word first. It will appear here automatically for today's practice.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun PracticeFlashcard(word: WordEntity, answerVisible: Boolean, hintVisible: Boolean, onToggleHint: () -> Unit, onToggleAnswer: () -> Unit) {
    var imageBitmap by remember(word.imagePath) { mutableStateOf<Bitmap?>(null) }
    var showImageViewer by remember { mutableStateOf(false) }
    LaunchedEffect(word.imagePath) {
        imageBitmap = withContext(Dispatchers.IO) {
            word.imagePath?.let { path ->
                runCatching {
                    val file = File(path)
                    if (file.exists()) {
                        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeFile(path, bounds)
                        if (bounds.outWidth > 0 && bounds.outHeight > 0) {
                            var sample = 1
                            while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
                            BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
                        } else null
                    } else null
                }.getOrNull()
            }
        }
    }

    ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Front side intentionally shows only the word. Image appears with Hint or Answer.
            Text(word.englishWord, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text("Try to remember the meaning", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)

            if (hintVisible && !answerVisible) {
                imageBitmap?.let { WordImagePreview(it, word.englishWord) { showImageViewer = true } }
                Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Example Sentence", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(word.sentence1, style = MaterialTheme.typography.bodyLarge)
                    word.sentence2?.takeIf { it.isNotBlank() }?.let { Text(it, style = MaterialTheme.typography.bodyLarge) }
                }
            }

            if (answerVisible) {
                imageBitmap?.let { WordImagePreview(it, word.englishWord) { showImageViewer = true } }
                Text(word.englishWord, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                word.partOfSpeech?.takeIf { it.isNotBlank() }?.let { Text(it, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                HorizontalDivider()
                DetailLine("English Meaning", word.englishMeaning)
                word.banglaMeaning?.takeIf { it.isNotBlank() }?.let { DetailLine("বাংলা অর্থ", it) }
                word.synonym?.takeIf { it.isNotBlank() }?.let { DetailLine("Synonyms", it) }
                word.antonym?.takeIf { it.isNotBlank() }?.let { DetailLine("Antonyms", it) }
                HorizontalDivider()
                Text("Example Sentences", modifier = Modifier.fillMaxWidth(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("1. ${word.sentence1}", modifier = Modifier.fillMaxWidth(), style = MaterialTheme.typography.bodyLarge)
                word.sentence2?.takeIf { it.isNotBlank() }?.let { Text("2. $it", modifier = Modifier.fillMaxWidth(), style = MaterialTheme.typography.bodyLarge) }
                TextButton(onClick = onToggleAnswer, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)) { Text("Hide Answer") }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = onToggleHint,
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp)
                    ) {
                        Icon(Icons.Default.Lightbulb, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(5.dp)); Text(if (hintVisible) "Hide Hint" else "Hint", style = MaterialTheme.typography.labelLarge)
                    }
                    Button(
                        onClick = onToggleAnswer,
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp)
                    ) {
                        Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(5.dp)); Text("Show Answer", style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
    }

    if (showImageViewer && imageBitmap != null) {
        ZoomableImageDialog(bitmap = imageBitmap!!, title = word.englishWord, onDismiss = { showImageViewer = false })
    }
}

@Composable
private fun WordImagePreview(bitmap: Bitmap, word: String, onClick: () -> Unit) {
    Image(
        bitmap = bitmap.asImageBitmap(),
        contentDescription = "Tap to enlarge image for $word",
        modifier = Modifier.fillMaxWidth().heightIn(max = 190.dp).clickable(onClick = onClick),
        contentScale = ContentScale.Fit
    )
    Text("Tap image to enlarge", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun ZoomableImageDialog(bitmap: Bitmap, title: String, onDismiss: () -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    val transformState = rememberTransformableState { zoom, pan, _ ->
        scale = (scale * zoom).coerceIn(1f, 5f)
        offsetX += pan.x
        offsetY += pan.y
    }
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth().fillMaxHeight(0.88f)) {
            Column(Modifier.fillMaxSize().padding(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(title, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close image") }
                }
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Image(
                        bitmap = bitmap.asImageBitmap(), contentDescription = "Zoomable image for $title",
                        modifier = Modifier.fillMaxSize().graphicsLayer(scaleX = scale, scaleY = scale, translationX = offsetX, translationY = offsetY).transformable(transformState),
                        contentScale = ContentScale.Fit
                    )
                }
                Text("Pinch to zoom · Drag to move", modifier = Modifier.align(Alignment.CenterHorizontally), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun DetailLine(title: String, value: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}
