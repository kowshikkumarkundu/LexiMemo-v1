package com.leximemo.app.data.repository

import androidx.room.withTransaction
import com.leximemo.app.data.local.LexiMemoDatabase
import com.leximemo.app.data.local.entity.ReviewHistoryEntity
import com.leximemo.app.data.local.entity.RevisionSessionEntity
import com.leximemo.app.data.local.entity.RevisionSessionItemEntity
import com.leximemo.app.data.local.entity.WordEntity
import com.leximemo.app.data.local.entity.RevisionEventEntity
import java.time.LocalDate

 data class RevisionCard(val word: WordEntity, val event: RevisionEventEntity)
 data class RevisionSessionState(val sessionId: Long?, val cards: List<RevisionCard>)

class RevisionRepository(private val db: LexiMemoDatabase) {
    suspend fun loadOrCreateSession(today: LocalDate = LocalDate.now()): RevisionSessionState = db.withTransaction {
        val dao = db.revisionDao()
        var session = dao.getActiveSession()
        if (session == null) {
            val pending = dao.getPendingEvents(today.toString())
            val selected = LinkedHashMap<Long, RevisionEventEntity>()
            pending.forEach { event -> if (!selected.containsKey(event.wordId)) selected[event.wordId] = event }
            if (selected.isEmpty()) return@withTransaction RevisionSessionState(null, emptyList())
            val now = System.currentTimeMillis()
            val sessionId = dao.insertSession(RevisionSessionEntity(
                sessionDate = today.toString(), createdAt = now, updatedAt = now,
                status = "ACTIVE", activeSlot = 1
            ))
            dao.insertSessionItems(selected.values.mapIndexed { index, event ->
                RevisionSessionItemEntity(sessionId = sessionId, wordId = event.wordId,
                    revisionEventId = event.id, position = index, addedAt = now)
            })
            session = dao.getActiveSession()
        }
        val active = session ?: return@withTransaction RevisionSessionState(null, emptyList())
        val items = dao.getSessionItems(active.id)
        val cards = items.mapNotNull { item ->
            val event = dao.getEventById(item.revisionEventId)
            val word = db.wordDao().getById(item.wordId)
            if (event != null && word != null) RevisionCard(word, event) else null
        }
        RevisionSessionState(active.id, cards)
    }

    suspend fun rate(sessionId: Long, card: RevisionCard, rating: String) = db.withTransaction {
        require(rating in setOf("MEMORIZED", "HINT_NEEDED", "FORGOT"))
        val now = System.currentTimeMillis()
        val changed = db.revisionDao().completeEvent(card.event.id, now)
        if (changed == 0) return@withTransaction
        db.revisionDao().insertReviewHistory(ReviewHistoryEntity(
            revisionEventId = card.event.id, rating = rating,
            reviewedDate = LocalDate.now().toString(), reviewedAt = now
        ))
        db.wordDao().updateLatestRating(card.word.id, rating, now)
        val remaining = db.revisionDao().getSessionItems(sessionId)
            .count { item -> db.revisionDao().getEventById(item.revisionEventId)?.isCompleted == false }
        if (remaining == 0) db.revisionDao().updateSessionStatus(sessionId, "COMPLETED", now, now)
        else db.revisionDao().updateSessionStatus(sessionId, "ACTIVE", now, null)
    }
}
