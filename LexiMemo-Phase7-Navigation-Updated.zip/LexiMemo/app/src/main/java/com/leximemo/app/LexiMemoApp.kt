package com.leximemo.app

import android.app.Application
import com.leximemo.app.data.local.LexiMemoDatabase
import com.leximemo.app.data.preferences.UserPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.async
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class LexiMemoApp : Application() {
    val database by lazy { LexiMemoDatabase.getInstance(this) }
    val preferences by lazy { UserPreferences(this) }
    lateinit var startupCleanup: Deferred<Unit>
        private set

    override fun onCreate() {
        super.onCreate()
        startupCleanup = CoroutineScope(SupervisorJob() + Dispatchers.IO).async {
            database.testDao().discardIncompleteSessions()
        }
    }
}
