package com.leximemo.app.presentation.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.leximemo.app.presentation.addword.AddWordScreen
import com.leximemo.app.presentation.dashboard.DashboardScreen
import com.leximemo.app.presentation.dictionary.DictionaryScreen
import com.leximemo.app.presentation.practice.PracticeScreen
import com.leximemo.app.presentation.revision.RevisionScreen
import com.leximemo.app.presentation.test.RandomTestScreen
import com.leximemo.app.presentation.test.TestHistoryScreen
import kotlinx.coroutines.launch

private data class Destination(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val mainDestinations = listOf(
    Destination("dashboard", "Dashboard", Icons.Default.Home),
    Destination("dictionary", "Dictionary", Icons.Default.Search),
    Destination("add", "Add Word", Icons.Default.Add),
    Destination("revision", "Revision", Icons.Default.Replay)
)

private val drawerDestinations = listOf(
    Destination("practice", "Practice", Icons.Default.Book),
    Destination("test", "Random Test", Icons.Default.CheckCircle),
    Destination("test-history", "Test History", Icons.Default.CheckCircle),
    Destination("favorites", "Favorites", Icons.Default.Favorite),
    Destination("collections", "Collections", Icons.Default.Book),
    Destination("progress", "Progress & Statistics", Icons.Default.Home)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LexiMemoNavigation() {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route ?: "dashboard"
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    BackHandler(enabled = drawerState.isOpen) {
        scope.launch { drawerState.close() }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Text("LexiMemo", modifier = Modifier.padding(horizontal = 24.dp, vertical = 20.dp), style = androidx.compose.material3.MaterialTheme.typography.titleLarge)
                drawerDestinations.forEach { destination ->
                    NavigationDrawerItem(
                        label = { Text(destination.label) },
                        icon = { Icon(destination.icon, contentDescription = null) },
                        selected = currentRoute == destination.route,
                        onClick = {
                            scope.launch { drawerState.close() }
                            navigateTopLevel(navController, destination.route)
                        },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }
                // Existing app functionality: Favorites is the Dictionary's built-in Favorites filter.
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(titleForRoute(currentRoute)) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Open navigation menu")
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    mainDestinations.forEach { destination ->
                        val selected = when (destination.route) {
                            "add" -> currentRoute == "add" || currentRoute.startsWith("add/")
                            else -> currentRoute == destination.route
                        }
                        NavigationBarItem(
                            selected = selected,
                            onClick = { navigateTopLevel(navController, destination.route) },
                            icon = { Icon(destination.icon, contentDescription = destination.label) },
                            label = { Text(destination.label, maxLines = 1, softWrap = false) },
                            alwaysShowLabel = true
                        )
                    }
                }
            }
        ) { padding ->
            NavHost(
                navController = navController,
                startDestination = "dashboard",
                modifier = Modifier.padding(padding)
            ) {
                composable("dashboard") { DashboardScreen(onAddWord = { navController.navigate("add") }) }
                composable("dictionary") { DictionaryScreen(onEditWord = { id -> navController.navigate("add/$id") }) }
                composable("add") { AddWordScreen() }
                composable("add/{wordId}") { entry ->
                    AddWordScreen(wordId = entry.arguments?.getString("wordId")?.toLongOrNull())
                }
                composable("revision") { RevisionScreen() }
                composable("practice") { PracticeScreen() }
                composable("test") { RandomTestScreen(onOpenHistory = { navController.navigate("test-history") }) }
                composable("test-history") { TestHistoryScreen() }
                composable("favorites") { DictionaryScreen(onEditWord = { id -> navController.navigate("add/$id") }, initialFavoritesOnly = true) }
                composable("collections") { DictionaryScreen(onEditWord = { id -> navController.navigate("add/$id") }) }
                composable("progress") { DashboardScreen(onAddWord = { navController.navigate("add") }) }
            }
        }
    }
}

private fun navigateTopLevel(navController: NavHostController, route: String) {
    val current = navController.currentDestination?.route
    if (current == route) return
    navController.navigate(route) {
        popUpTo("dashboard") { inclusive = false; saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

private fun titleForRoute(route: String): String = when {
    route.startsWith("add") -> "Add Word"
    route == "dashboard" -> "Dashboard"
    route == "dictionary" -> "Dictionary"
    route == "revision" -> "Revision"
    route == "practice" -> "Practice"
    route == "test" -> "Random Test"
    route == "test-history" -> "Test History"
    route == "favorites" -> "Favorites"
    route == "collections" -> "Collections"
    route == "progress" -> "Progress & Statistics"
    else -> "LexiMemo"
}
