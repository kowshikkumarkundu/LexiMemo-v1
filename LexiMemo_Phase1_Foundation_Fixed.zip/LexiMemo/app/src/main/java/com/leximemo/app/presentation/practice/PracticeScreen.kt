package com.leximemo.app.presentation.practice

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun PracticeScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Today's Practice", style = MaterialTheme.typography.headlineSmall)
        Text("Practice flashcards will be implemented in Phase 4.")
    }
}
