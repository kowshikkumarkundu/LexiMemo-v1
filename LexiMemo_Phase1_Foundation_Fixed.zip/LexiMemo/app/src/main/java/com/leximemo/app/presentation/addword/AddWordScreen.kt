package com.leximemo.app.presentation.addword

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun AddWordScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Add New Word", style = MaterialTheme.typography.headlineSmall)
        Text("The vocabulary form will be implemented in Phase 2.", style = MaterialTheme.typography.bodyMedium)
    }
}
