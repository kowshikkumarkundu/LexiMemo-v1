package com.leximemo.app.presentation.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun DashboardScreen(onAddWord: () -> Unit) {
    val date = LocalDate.now()
    val dateText = date.format(DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.ENGLISH))
    val dayText = date.format(DateTimeFormatter.ofPattern("EEEE", Locale.ENGLISH))
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Text(dateText, style = MaterialTheme.typography.titleLarge)
        Text(dayText, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Daily Target", style = MaterialTheme.typography.titleMedium)
                Text("0 / 5 Words", style = MaterialTheme.typography.headlineSmall)
                LinearProgressIndicator(progress = { 0f }, modifier = Modifier.fillMaxWidth())
                Text("5 words remaining", style = MaterialTheme.typography.bodySmall)
            }
        }
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Start building your vocabulary", style = MaterialTheme.typography.titleMedium)
                Text("Save your first word and begin your learning journey.", style = MaterialTheme.typography.bodyMedium)
                Button(onClick = onAddWord) { Text("Add Your First Word") }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedCard(Modifier.weight(1f)) { Column(Modifier.padding(14.dp)) { Text("Today's Practice"); Text("0 words") } }
            OutlinedCard(Modifier.weight(1f)) { Column(Modifier.padding(14.dp)) { Text("Today's Revision"); Text("0 due") } }
        }
    }
}
