package com.leximemo.app

import android.app.Application
import com.leximemo.app.data.local.LexiMemoDatabase
import com.leximemo.app.data.preferences.UserPreferences

class LexiMemoApp : Application() {
    val database by lazy { LexiMemoDatabase.getInstance(this) }
    val preferences by lazy { UserPreferences(this) }
}
