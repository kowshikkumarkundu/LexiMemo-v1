package com.leximemo.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.leximemo.app.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface WordDao {
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(word: WordEntity): Long
    @Update suspend fun update(word: WordEntity)
    @Query("DELETE FROM words WHERE id = :id") suspend fun deleteById(id: Long)
    @Query("SELECT * FROM words ORDER BY addedDate DESC, id DESC") fun observeAll(): Flow<List<WordEntity>>
    @Query("SELECT * FROM words WHERE normalizedWord = :normalized LIMIT 1") suspend fun findByNormalizedWord(normalized: String): WordEntity?
    @Query("SELECT COUNT(*) FROM words WHERE addedDate = :date") fun observeAddedCount(date: String): Flow<Int>
}

@Dao
interface RevisionDao {
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertEvents(events: List<RevisionEventEntity>)
    @Query("SELECT * FROM revision_events WHERE scheduledDate <= :today AND isCompleted = 0 ORDER BY scheduledDate ASC, id ASC") suspend fun getPendingEvents(today: String): List<RevisionEventEntity>
    @Query("SELECT COUNT(*) FROM revision_events WHERE scheduledDate <= :today AND isCompleted = 0") fun observePendingEventCount(today: String): Flow<Int>
    @Query("SELECT * FROM revision_sessions WHERE status = 'ACTIVE' LIMIT 1") suspend fun getActiveSession(): RevisionSessionEntity?
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertSession(session: RevisionSessionEntity): Long
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertSessionItems(items: List<RevisionSessionItemEntity>)
    @Query("SELECT * FROM revision_session_items WHERE sessionId = :sessionId ORDER BY position ASC") suspend fun getSessionItems(sessionId: Long): List<RevisionSessionItemEntity>
}

@Dao
interface DailyActivityDao {
    @Query("SELECT * FROM daily_activity WHERE date = :date LIMIT 1") suspend fun get(date: String): DailyActivityEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(activity: DailyActivityEntity)
    @Query("SELECT * FROM daily_activity ORDER BY date DESC LIMIT 7") fun observeLastSevenDays(): Flow<List<DailyActivityEntity>>
}

@Dao
interface TestDao {
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertSession(session: TestSessionEntity): Long
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertResults(results: List<TestResultEntity>)
    @Query("DELETE FROM test_sessions WHERE completedAt IS NULL") suspend fun discardIncompleteSessions()
    @Query("SELECT * FROM test_sessions WHERE completedAt IS NOT NULL ORDER BY completedAt DESC") fun observeHistory(): Flow<List<TestSessionEntity>>
}
