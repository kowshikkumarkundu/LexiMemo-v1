package com.leximemo.app.presentation.revision

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun RevisionScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Today's Revision", style = MaterialTheme.typography.headlineSmall)
        Text("The persistent spaced-repetition engine will be implemented in Phase 5.")
    }
}
