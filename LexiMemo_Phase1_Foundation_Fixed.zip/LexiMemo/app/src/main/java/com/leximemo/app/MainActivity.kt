package com.leximemo.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.leximemo.app.presentation.navigation.LexiMemoNavigation
import com.leximemo.app.presentation.theme.LexiMemoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LexiMemoTheme { LexiMemoNavigation() } }
    }
}
