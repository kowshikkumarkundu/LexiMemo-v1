package com.leximemo.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.leximemo.app.data.local.dao.*
import com.leximemo.app.data.local.entity.*

@Database(
    entities = [WordEntity::class, RevisionEventEntity::class, ReviewHistoryEntity::class, DailyActivityEntity::class, TestSessionEntity::class, TestResultEntity::class, RevisionSessionEntity::class, RevisionSessionItemEntity::class],
    version = 1,
    exportSchema = true
)
abstract class LexiMemoDatabase : RoomDatabase() {
    abstract fun wordDao(): WordDao
    abstract fun revisionDao(): RevisionDao
    abstract fun dailyActivityDao(): DailyActivityDao
    abstract fun testDao(): TestDao

    companion object {
        @Volatile private var INSTANCE: LexiMemoDatabase? = null
        fun getInstance(context: Context): LexiMemoDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, LexiMemoDatabase::class.java, "leximemo.db")
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_revision_sessions_active_slot ON revision_sessions(activeSlot) WHERE activeSlot IS NOT NULL")
                        db.execSQL("CREATE TRIGGER IF NOT EXISTS revision_session_active_slot_insert AFTER INSERT ON revision_sessions BEGIN UPDATE revision_sessions SET activeSlot = CASE WHEN NEW.status = 'ACTIVE' THEN 1 ELSE NULL END WHERE id = NEW.id; END")
                        db.execSQL("CREATE TRIGGER IF NOT EXISTS revision_session_active_slot_update AFTER UPDATE OF status ON revision_sessions BEGIN UPDATE revision_sessions SET activeSlot = CASE WHEN NEW.status = 'ACTIVE' THEN 1 ELSE NULL END WHERE id = NEW.id; END")
                    }
                })
                .build().also { INSTANCE = it }
        }
    }
}
