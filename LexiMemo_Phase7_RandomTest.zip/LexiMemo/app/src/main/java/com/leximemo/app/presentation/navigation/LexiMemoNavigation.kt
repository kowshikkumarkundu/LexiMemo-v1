package com.leximemo.app.presentation.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.leximemo.app.presentation.addword.AddWordScreen
import com.leximemo.app.presentation.dashboard.DashboardScreen
import com.leximemo.app.presentation.dictionary.DictionaryScreen
import com.leximemo.app.presentation.practice.PracticeScreen
import com.leximemo.app.presentation.revision.RevisionScreen
import com.leximemo.app.presentation.test.RandomTestScreen

data class Destination(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val destinations = listOf(
    Destination("dashboard", "Dashboard", Icons.Default.Home),
    Destination("add", "Add Word", Icons.Default.Add),
    Destination("practice", "Practice", Icons.Default.Book),
    Destination("revision", "Revision", Icons.Default.Replay),
    Destination("dictionary", "Dictionary", Icons.Default.Search),
    Destination("test", "Test", Icons.Default.CheckCircle)
)

@Composable
fun LexiMemoNavigation() {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    Scaffold(bottomBar = {
        NavigationBar {
            destinations.forEach { destination ->
                NavigationBarItem(
                    selected = currentRoute == destination.route,
                    onClick = {
                        if (currentRoute != destination.route) {
                            navController.navigate(destination.route) {
                                // Keep Dashboard as the single root; switching tabs always
                                // removes the previous tab from the active back stack.
                                popUpTo("dashboard") { inclusive = false; saveState = false }
                                launchSingleTop = true
                                restoreState = false
                            }
                        }
                    },
                    icon = { Icon(destination.icon, contentDescription = destination.label) },
                    label = { Text(destination.label) },
                    alwaysShowLabel = true
                )
            }
        }
    }) { padding ->
        NavHost(navController, startDestination = "dashboard", modifier = Modifier.padding(padding)) {
            composable("dashboard") { DashboardScreen(onAddWord = { navController.navigate("add") }) }
            composable("add") { AddWordScreen() }
            composable("add/{wordId}") { entry ->
                AddWordScreen(wordId = entry.arguments?.getString("wordId")?.toLongOrNull())
            }
            composable("dictionary") {
                DictionaryScreen(onEditWord = { id -> navController.navigate("add/$id") })
            }
            composable("practice") { PracticeScreen() }
            composable("revision") { RevisionScreen() }
            composable("test") { RandomTestScreen() }
        }
    }
}
