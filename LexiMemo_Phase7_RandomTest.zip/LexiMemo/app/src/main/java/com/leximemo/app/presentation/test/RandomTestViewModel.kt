package com.leximemo.app.presentation.test

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import com.leximemo.app.LexiMemoApp
import com.leximemo.app.data.local.entity.TestResultEntity
import com.leximemo.app.data.local.entity.TestSessionEntity
import com.leximemo.app.data.local.entity.WordEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private const val SOURCE_ALL = "DICTIONARY"
data class TestQuestion(val word: WordEntity, val result: String? = null)
data class ActiveTest(val sessionId: Long, val source: String, val requestedCount: Int, val questions: List<TestQuestion>, val position: Int = 0, val answerVisible: Boolean = false) {
    val current: TestQuestion? get() = questions.getOrNull(position)
}
data class TestSummary(val session: TestSessionEntity, val questions: List<TestQuestion>)

class RandomTestViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as LexiMemoApp
    private val db = app.database
    private val dao = db.testDao()
    val history: StateFlow<List<TestSessionEntity>> = dao.observeHistory().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val activeTest = MutableStateFlow<ActiveTest?>(null)
    val lastSummary = MutableStateFlow<TestSummary?>(null)
    val selectedSource = MutableStateFlow(SOURCE_ALL)
    val requestedCount = MutableStateFlow("10")
    val message = MutableStateFlow<String?>(null)

    init { viewModelScope.launch { app.startupCleanup.await() } }
    fun selectSource(source: String) { selectedSource.value = source }
    fun setRequestedCount(value: String) { requestedCount.value = value.filter(Char::isDigit).take(3) }

    fun startTest() = viewModelScope.launch {
        app.startupCleanup.await()
        val count = requestedCount.value.toIntOrNull()
        if (count == null || count <= 0) { message.value = "Enter a question count greater than zero."; return@launch }
        val allWords = db.wordDao().observeAll().first()
        val source = selectedSource.value
        val eligible = when (source) {
            "FAVORITES" -> allWords.filter { it.isFavorite }
            "MEMORIZED" -> allWords.filter { it.latestRating == "MEMORIZED" }
            "HINT_NEEDED" -> allWords.filter { it.latestRating == "HINT_NEEDED" }
            "FORGOT" -> allWords.filter { it.latestRating == "FORGOT" }
            else -> allWords
        }.shuffled()
        if (eligible.isEmpty()) { message.value = "No words are available in this source."; return@launch }
        val chosen = eligible.take(count)
        val now = System.currentTimeMillis()
        val sessionId = db.withTransaction {
            val id = dao.insertSession(TestSessionEntity(source = source, requestedCount = count, actualCount = chosen.size, startedAt = now))
            dao.insertResults(chosen.mapIndexed { index, word -> TestResultEntity(sessionId = id, wordId = word.id, position = index) })
            id
        }
        lastSummary.value = null
        message.value = null
        activeTest.value = ActiveTest(sessionId, source, count, chosen.map { TestQuestion(it) })
    }

    fun revealAnswer() { activeTest.value = activeTest.value?.copy(answerVisible = true) }

    fun answer(correct: Boolean) {
        viewModelScope.launch {
            val test = activeTest.value ?: return@launch
            val current = test.current ?: return@launch
            val result = if (correct) "CORRECT" else "INCORRECT"
            db.withTransaction {
                dao.saveAnswer(test.sessionId, current.word.id, result)
                val results = dao.getResults(test.sessionId)
                if (results.all { it.result != null }) {
                    val correctCount = results.count { it.result == "CORRECT" }
                    dao.finishSession(test.sessionId, correctCount, results.size - correctCount, System.currentTimeMillis())
                }
            }
            val updated = test.questions.mapIndexed { index, q -> if (index == test.position) q.copy(result = result) else q }
            if (test.position + 1 >= test.questions.size) {
                dao.getSession(test.sessionId)?.let { lastSummary.value = TestSummary(it, updated) }
                activeTest.value = null
            } else activeTest.value = test.copy(questions = updated, position = test.position + 1, answerVisible = false)
        }
    }

    fun startNewTest() { lastSummary.value = null }

    fun loadHistoryDetails(session: TestSessionEntity, onLoaded: (TestSummary) -> Unit) = viewModelScope.launch {
        val questions = dao.getResults(session.id).mapNotNull { result -> db.wordDao().getById(result.wordId)?.let { TestQuestion(it, result.result) } }
        onLoaded(TestSummary(session, questions))
    }
}
