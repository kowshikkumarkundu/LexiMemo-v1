package com.leximemo.app.presentation.practice

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.leximemo.app.data.local.entity.WordEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun PracticeScreen(viewModel: PracticeViewModel = viewModel()) {
    val words by viewModel.todayWords.collectAsState()
    var currentIndex by remember { mutableIntStateOf(0) }
    var answerVisible by remember { mutableStateOf(false) }
    var hintVisible by remember { mutableStateOf(false) }
    val viewedIds = remember { mutableStateListOf<Long>() }

    LaunchedEffect(words.map { it.id }) {
        viewedIds.retainAll(words.map { it.id }.toSet())
        answerVisible = false
        hintVisible = false
        if (words.isEmpty()) {
            currentIndex = 0
            viewedIds.clear()
        } else if (currentIndex > words.lastIndex) {
            currentIndex = words.lastIndex
        }
    }

    val currentWord = words.getOrNull(currentIndex)
    val isComplete = words.isNotEmpty() && words.all { it.id in viewedIds }

    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Today's Practice", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "Review the words you added today. This practice can be repeated anytime.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        if (words.isEmpty()) {
            EmptyPracticeState()
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Card ${currentIndex + 1} of ${words.size}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                Text("${words.count { it.id in viewedIds }}/${words.size} viewed", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            }
            LinearProgressIndicator(
                progress = { (words.count { it.id in viewedIds }.toFloat() / words.size.coerceAtLeast(1)).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth()
            )

            currentWord?.let { word ->
                PracticeFlashcard(
                    word = word,
                    answerVisible = answerVisible,
                    hintVisible = hintVisible,
                    onToggleHint = { hintVisible = !hintVisible },
                    onToggleAnswer = {
                        answerVisible = !answerVisible
                        if (answerVisible && word.id !in viewedIds) viewedIds.add(word.id)
                    }
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = {
                        currentIndex = (currentIndex - 1).coerceAtLeast(0)
                        answerVisible = false
                        hintVisible = false
                    },
                    enabled = currentIndex > 0,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = null)
                    Spacer(Modifier.width(6.dp)); Text("Previous")
                }
                Button(
                    onClick = {
                        currentIndex = (currentIndex + 1).coerceAtMost(words.lastIndex)
                        answerVisible = false
                        hintVisible = false
                    },
                    enabled = currentIndex < words.lastIndex,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Next"); Spacer(Modifier.width(6.dp))
                    Icon(Icons.Default.ArrowForward, contentDescription = null)
                }
            }

            if (isComplete) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Practice completed!", fontWeight = FontWeight.Bold)
                            Text("You viewed all ${words.size} words added today.", style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = {
                            currentIndex = 0
                            answerVisible = false
                            hintVisible = false
                            viewedIds.clear()
                        }) {
                            Icon(Icons.Default.Replay, contentDescription = null)
                            Text("Again")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyPracticeState() {
    ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(42.dp))
            Text("No words added today", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(
                "Add a new word first. It will appear here automatically for today's practice.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun PracticeFlashcard(word: WordEntity, answerVisible: Boolean, hintVisible: Boolean, onToggleHint: () -> Unit, onToggleAnswer: () -> Unit) {
    var imageBitmap by remember(word.imagePath) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(word.imagePath) {
        imageBitmap = withContext(Dispatchers.IO) {
            word.imagePath?.let { path ->
                runCatching {
                    val file = File(path)
                    if (file.exists()) {
                        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeFile(path, bounds)
                        if (bounds.outWidth > 0 && bounds.outHeight > 0) {
                            var sample = 1
                            while (bounds.outWidth / sample > 1200 || bounds.outHeight / sample > 1200) sample *= 2
                            BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
                        } else null
                    } else null
                }.getOrNull()
            }
        }
    }

    ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
        LazyColumn(
            modifier = Modifier.fillMaxWidth().heightIn(min = 250.dp, max = 470.dp),
            contentPadding = PaddingValues(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                if (imageBitmap != null) {
                    Image(
                        bitmap = imageBitmap!!.asImageBitmap(),
                        contentDescription = "Image for ${word.englishWord}",
                        modifier = Modifier.fillMaxWidth().heightIn(max = 180.dp),
                        contentScale = ContentScale.Fit
                    )
                }
                Text(word.englishWord, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                word.partOfSpeech?.takeIf { it.isNotBlank() }?.let {
                    Text(it, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (!answerVisible) {
                item {
                    Text("Try to remember the meaning", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                item {
                    OutlinedButton(onClick = onToggleHint, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Lightbulb, contentDescription = null)
                        Spacer(Modifier.width(8.dp)); Text(if (hintVisible) "Hide Hint" else "Hint · Show example sentence")
                    }
                    if (hintVisible) {
                        Text(word.sentence1, style = MaterialTheme.typography.bodyMedium)
                        word.sentence2?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
                    }
                    Button(onClick = onToggleAnswer, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Visibility, contentDescription = null)
                        Spacer(Modifier.width(8.dp)); Text("Show Answer")
                    }
                }
            } else {
                item {
                    DetailLine("English Meaning", word.englishMeaning)
                    DetailLine("বাংলা অর্থ", word.banglaMeaning)
                    word.synonym?.let { DetailLine("Synonyms", it) }
                    word.antonym?.let { DetailLine("Antonyms", it) }
                    HorizontalDivider()
                    Text("Example Sentences", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text("1. ${word.sentence1}", style = MaterialTheme.typography.bodyMedium)
                    word.sentence2?.let { Text("2. $it", style = MaterialTheme.typography.bodyMedium) }
                    TextButton(onClick = onToggleAnswer) { Text("Hide Answer") }
                }
            }
        }
    }
}

@Composable
private fun DetailLine(title: String, value: String) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}
