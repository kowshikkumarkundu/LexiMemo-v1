package com.leximemo.app.presentation.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun DashboardScreen(onAddWord: () -> Unit, viewModel: DashboardViewModel = viewModel()) {
    val date = LocalDate.now()
    val dateText = date.format(DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.ENGLISH))
    val dayText = date.format(DateTimeFormatter.ofPattern("EEEE", Locale.ENGLISH))
    val activity by viewModel.activity.collectAsState()
    val defaultTarget by viewModel.target.collectAsState()
    val added = activity?.addedWordCount ?: 0
    val target = activity?.targetForDay ?: defaultTarget
    val remaining = (target - added).coerceAtLeast(0)

    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Text(dateText, style = MaterialTheme.typography.titleLarge)
        Text(dayText, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Daily Target", style = MaterialTheme.typography.titleMedium)
                Text("$added / $target Words", style = MaterialTheme.typography.headlineSmall)
                LinearProgressIndicator(progress = { if (target > 0) (added.toFloat() / target).coerceIn(0f, 1f) else 0f }, modifier = Modifier.fillMaxWidth())
                Text("$remaining words remaining", style = MaterialTheme.typography.bodySmall)
            }
        }
        if (added == 0) {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Start building your vocabulary", style = MaterialTheme.typography.titleMedium)
                    Text("Save your first word and begin your learning journey.", style = MaterialTheme.typography.bodyMedium)
                    Button(onClick = onAddWord) { Text("Add Your First Word") }
                }
            }
        } else {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Great progress today!", style = MaterialTheme.typography.titleMedium)
                    Text("You added $added ${if (added == 1) "word" else "words"} today.")
                    OutlinedButton(onClick = onAddWord) { Text("Add Another Word") }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedCard(Modifier.weight(1f)) { Column(Modifier.padding(14.dp)) { Text("Today's Practice"); Text("0 words") } }
            OutlinedCard(Modifier.weight(1f)) { Column(Modifier.padding(14.dp)) { Text("Today's Revision"); Text("0 due") } }
        }
    }
}
