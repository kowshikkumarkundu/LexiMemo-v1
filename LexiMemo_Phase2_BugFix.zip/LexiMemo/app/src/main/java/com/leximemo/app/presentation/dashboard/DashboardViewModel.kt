package com.leximemo.app.presentation.dashboard

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.leximemo.app.LexiMemoApp
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import java.time.LocalDate

class DashboardViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as LexiMemoApp
    private val today = LocalDate.now().toString()
    val activity = app.database.dailyActivityDao().observe(today)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    val target = app.preferences.defaultDailyTarget
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 5)
}
