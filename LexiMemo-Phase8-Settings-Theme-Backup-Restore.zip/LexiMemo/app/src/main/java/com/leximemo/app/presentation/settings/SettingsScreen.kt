package com.leximemo.app.presentation.settings

import android.app.Activity
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.leximemo.app.LexiMemoApp
import com.leximemo.app.MainActivity
import com.leximemo.app.data.backup.BackupRestoreManager
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val app = context.applicationContext as LexiMemoApp
    val scope = rememberCoroutineScope()
    val themeMode by app.preferences.themeMode.collectAsState(initial = "LIGHT")
    val dailyTarget by app.preferences.defaultDailyTarget.collectAsState(initial = 5)
    var targetText by remember(dailyTarget) { mutableStateOf(dailyTarget.toString()) }
    var busy by remember { mutableStateOf(false) }
    var restoreUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var showRestoreConfirmation by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }

    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) scope.launch {
            busy = true
            status = null
            runCatching { BackupRestoreManager.createBackup(context, uri) }
                .onSuccess { status = "Backup created successfully." }
                .onFailure { status = "Backup failed: ${it.message ?: "Unknown error"}" }
            busy = false
        }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            restoreUri = uri
            showRestoreConfirmation = true
        }
    }

    if (showRestoreConfirmation) {
        AlertDialog(
            onDismissRequest = { showRestoreConfirmation = false; restoreUri = null },
            title = { Text("Restore backup?") },
            text = { Text("Restoring replaces the current words, revision history, test history and images with the selected backup. The app will validate the backup first. Make sure you have a recent backup of your current data.") },
            confirmButton = {
                TextButton(onClick = {
                    val uri = restoreUri ?: return@TextButton
                    showRestoreConfirmation = false
                    scope.launch {
                        busy = true
                        status = null
                        runCatching { BackupRestoreManager.restoreBackup(context, uri) }
                            .onSuccess {
                                Toast.makeText(context, "Restore completed. Restarting LexiMemo…", Toast.LENGTH_LONG).show()
                                val restart = Intent(context, MainActivity::class.java).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                                }
                                context.startActivity(restart)
                                (context as? Activity)?.finish()
                            }
                            .onFailure { status = "Restore failed: ${it.message ?: "Unknown error"}" }
                        busy = false
                    }
                    restoreUri = null
                }, enabled = !busy) { Text("Restore") }
            },
            dismissButton = { TextButton(onClick = { showRestoreConfirmation = false; restoreUri = null }) { Text("Cancel") } }
        )
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall)

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Appearance", style = MaterialTheme.typography.titleMedium)
                Text("Choose how LexiMemo looks.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                listOf("LIGHT" to "Light", "DARK" to "Dark", "SYSTEM" to "Follow system").forEach { (value, label) ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        RadioButton(selected = themeMode == value, onClick = { scope.launch { app.preferences.setThemeMode(value) } })
                        Text(label)
                    }
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Daily Target", style = MaterialTheme.typography.titleMedium)
                Text("Set how many new words you want to add each day.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(
                    value = targetText,
                    onValueChange = { value -> if (value.length <= 4 && value.all(Char::isDigit)) targetText = value },
                    label = { Text("Words per day") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = {
                    val value = targetText.toIntOrNull()
                    if (value == null || value !in 1..9999) status = "Daily target must be between 1 and 9999."
                    else scope.launch {
                        app.preferences.setDefaultDailyTarget(value)
                        status = "Daily target saved."
                    }
                }, enabled = !busy) { Text("Save Daily Target") }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Backup & Restore", style = MaterialTheme.typography.titleMedium)
                Text("Create a ZIP backup on your device or restore from a previous LexiMemo backup. Nothing is uploaded online.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(onClick = { backupLauncher.launch("LexiMemo-Backup.zip") }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Text("Create Backup")
                }
                OutlinedButton(onClick = { restoreLauncher.launch(arrayOf("application/zip", "application/octet-stream")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Text("Restore Backup")
                }
                if (busy) Text("Please wait…", color = MaterialTheme.colorScheme.primary)
            }
        }

        if (status != null) {
            HorizontalDivider()
            Text(status!!, color = if (status!!.contains("failed", ignoreCase = true) || status!!.contains("must be", ignoreCase = true)) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
        }
        Spacer(Modifier.height(8.dp))
    }
}
