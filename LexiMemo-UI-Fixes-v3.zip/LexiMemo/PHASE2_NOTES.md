# LexiMemo Phase 2 — Add & Manage Words

## Included
- Required English word, English meaning, Bangla meaning, and first example sentence.
- Optional second sentence, part of speech, synonym, antonym, and image.
- Android Photo Picker integration; selected images are copied into app-private `files/word_images` storage.
- Image import rejects files larger than 5 MiB and cleans up partial copies on failure.
- Word normalization uses `trim().lowercase(Locale.ROOT)` and the database unique index remains the final duplicate guard.
- Word creation, five fixed revision events (+1, +3, +7, +15, +30 days), and daily activity snapshot are committed in one Room transaction.
- Edit preserves the original added date and existing revision schedule.
- Delete cascades related Room records and removes the app-owned image file.
- Dashboard daily target progress reads the persisted daily activity snapshot.

## Build note
The source archive was inspected and packaged. It has not been compiled in this environment; run the repository GitHub Actions workflow to verify the Android build.
