# LexiMemo Phase 8 — Settings, Theme & Backup/Restore

Implemented in this phase:
- Settings destination in the navigation drawer.
- Light, Dark and Follow System theme modes persisted through DataStore.
- Daily Target editing (1–9999) persisted through the existing DataStore preference used by the dashboard and Add Word flow.
- Manual ZIP backup through Android's Storage Access Framework.
- Backup contains a consistent database snapshot, all app-owned word images, format/schema metadata and SHA-256 checksums.
- Restore validates archive paths and size, manifest version, database/image checksums, SQLite integrity, foreign keys and schema version before installation.
- Restore uses a staged database, preserves rollback copies, swaps the database and images, reopens Room, and restores the previous files if installation fails.
- No network, cloud, automatic backup, analytics, ads or new permissions added.

Important verification note:
- Source-level ZIP integrity can be checked locally, but an Android Gradle build and device-level backup/restore test must still be run in GitHub Actions/on a device.
- Database schema is currently version 1. Future Room schema changes must update the backup schema compatibility handling and retain migrations.
