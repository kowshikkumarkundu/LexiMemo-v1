# Phase 7 — Random Test & Test History

- Added a Random Test destination.
- Test source filters: All Words (Dictionary), Favorites, Memorized, Hint Needed, Forgot.
- User enters a positive question count. If fewer eligible words exist, all eligible words are used.
- Questions are shuffled and selected without duplicates.
- Each question shows the English word first. The answer is revealed only after Show Answer.
- The user must mark Correct or Incorrect; there is no Skip action. Each answer is persisted immediately.
- Completed tests show correct/incorrect totals, accuracy, source, completion date/time, and question review.
- Test History lists completed sessions newest-first and provides question-level details.
- Incomplete sessions are deleted on app/ViewModel startup and are not included in history.
- Random Test does not update word ratings, favorites, revision events, revision history, or revision schedule.
- Existing Room schema version remains 1; this phase uses the test_sessions and test_results tables already present in the foundation schema.
