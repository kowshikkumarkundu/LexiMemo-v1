# LexiMemo — Android Project Foundation

This is the Phase 1 starter project for the approved LexiMemo Technical Specification v1.0.

## Included
- Kotlin + Jetpack Compose + Material 3 foundation
- MVVM-ready package structure
- Bottom navigation shell (Dashboard, Add Word, Practice, Revision)
- Initial Dashboard empty state
- Room schema foundation for all eight specification tables
- DataStore preferences for default daily target and theme mode
- No INTERNET permission and no broad storage permission

## Requirements
- Android Studio with Android SDK 36 installed
- JDK 17
- Gradle 8.13 (wrapper distribution configured)

## Open the project
Open this folder in Android Studio and allow Gradle Sync. This source archive includes the Gradle wrapper distribution configuration; if Android Studio asks to regenerate the wrapper launcher, use its Gradle wrapper task.

## Important implementation note
This is the Phase 1 foundation, not a feature-complete app or release APK. Add/Edit/Delete, image storage, production navigation drawer, full theme persistence, transactional use cases, revision logic, backup/restore and tests are intentionally scheduled for later phases.

## Package
`com.leximemo.app`

## Offline guarantee
The manifest intentionally declares no `INTERNET` permission.

## Phase 3
Dashboard, configurable daily target, daily progress, total word count, due revision word count, and current streak with one-day grace are included. See `PHASE3_NOTES.md`.

## Phase 4
Today's Practice is implemented as a repeatable, in-memory flashcard session over words added on the device-local current date. It is isolated from revision schedules, ratings, daily target/streak records, and Practice History. See `PHASE4_NOTES.md`.
