# LexiMemo Phase 3 — Dashboard, Daily Target & Streak

## Included
- Dashboard shows the current date/day, daily word-add progress, total vocabulary count, due revision word count, and current streak.
- Daily target can be selected from 5/10/15/20/25/30 or entered as a custom value from 1 to 100.
- The default target is persisted in DataStore.
- The target for a date is snapshotted when the first word is added that day. Changing the default later does not rewrite that day's target.
- Streak counts days where addedWordCount >= targetForDay. One missed calendar day is tolerated; a second missed day ends the current streak.
- Deleting a word decrements that date's added-word count so dashboard progress does not remain inflated.
- Existing Phase 2 navigation, add/edit word, image storage, and fixed revision schedule are retained.

## Validation
- Source and ZIP structure checks are performed when packaging.
- This archive has not been compiled with the Android Gradle Plugin in this environment. Use the repository GitHub Actions workflow to perform the Android build.
