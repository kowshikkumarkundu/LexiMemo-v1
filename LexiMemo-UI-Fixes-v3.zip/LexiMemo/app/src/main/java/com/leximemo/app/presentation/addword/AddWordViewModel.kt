package com.leximemo.app.presentation.addword

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.leximemo.app.LexiMemoApp
import com.leximemo.app.data.image.WordImageStorage
import com.leximemo.app.data.local.entity.WordEntity
import com.leximemo.app.data.repository.SaveWordResult
import com.leximemo.app.data.repository.WordRepository
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AddWordViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as LexiMemoApp
    private val repository = WordRepository(app.database)
    val words = repository.words.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    var message: String? by mutableStateOf(null)
        private set
    var isSaving: Boolean by mutableStateOf(false)
        private set

    fun save(
        englishWord: String,
        englishMeaning: String,
        banglaMeaning: String,
        sentence1: String,
        sentence2: String,
        partOfSpeech: String,
        synonym: String,
        antonym: String,
        selectedImage: Uri?,
        editingWord: WordEntity?,
        onFinished: (Boolean) -> Unit
    ) {
        if (englishWord.isBlank() || englishMeaning.isBlank() || banglaMeaning.isBlank() || sentence1.isBlank()) {
            message = "Please fill in all required fields."
            onFinished(false)
            return
        }
        if (isSaving) return
        isSaving = true
        viewModelScope.launch {
            var savedImagePath: String? = null
            try {
                if (selectedImage != null) {
                    savedImagePath = WordImageStorage.importImage(getApplication(), selectedImage)
                }
                val result = if (editingWord == null) {
                    val target = app.preferences.defaultDailyTarget.first()
                    repository.saveWord(
                        englishWord, englishMeaning, banglaMeaning, sentence1,
                        sentence2, partOfSpeech, synonym, antonym, savedImagePath, target
                    )
                } else {
                    repository.updateWord(
                        editingWord, englishWord, englishMeaning, banglaMeaning, sentence1,
                        sentence2, partOfSpeech, synonym, antonym,
                        savedImagePath ?: editingWord.imagePath
                    )
                }
                when (result) {
                    is SaveWordResult.Saved -> {
                        if (editingWord != null && savedImagePath != null && editingWord.imagePath != savedImagePath) {
                            WordImageStorage.deleteIfOwned(editingWord.imagePath)
                        }
                        message = if (editingWord == null) "Word saved successfully. Five revision dates created." else "Word updated successfully."
                        onFinished(true)
                    }
                    SaveWordResult.Duplicate -> {
                        WordImageStorage.deleteIfOwned(savedImagePath)
                        message = "This word already exists."
                        onFinished(false)
                    }
                    is SaveWordResult.Failed -> {
                        WordImageStorage.deleteIfOwned(savedImagePath)
                        message = result.message
                        onFinished(false)
                    }
                }
            } catch (error: Exception) {
                WordImageStorage.deleteIfOwned(savedImagePath)
                message = error.message ?: "Unable to save image."
                onFinished(false)
            } finally {
                isSaving = false
            }
        }
    }

    fun delete(word: WordEntity) {
        viewModelScope.launch {
            runCatching { repository.deleteWord(word) }
                .onSuccess { message = "Word deleted." }
                .onFailure { message = it.message ?: "Could not delete word." }
        }
    }

    fun consumeMessage() { message = null }
}
