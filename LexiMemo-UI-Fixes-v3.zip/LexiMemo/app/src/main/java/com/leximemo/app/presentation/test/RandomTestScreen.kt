package com.leximemo.app.presentation.test

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.leximemo.app.data.local.entity.TestSessionEntity
import com.leximemo.app.presentation.components.WordImage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val testSources = listOf("DICTIONARY" to "All Words", "FAVORITES" to "Favorites", "MEMORIZED" to "Memorized", "HINT_NEEDED" to "Hint Needed", "FORGOT" to "Forgot")

@Composable
fun RandomTestScreen(onOpenHistory: (() -> Unit)? = null, viewModel: RandomTestViewModel = viewModel()) {
    val active by viewModel.activeTest.collectAsState()
    val summary by viewModel.lastSummary.collectAsState()
    val source by viewModel.selectedSource.collectAsState()
    val count by viewModel.requestedCount.collectAsState()
    val message by viewModel.message.collectAsState()
    val history by viewModel.history.collectAsState()
    var historyDetails by remember { mutableStateOf<TestSummary?>(null) }
    var showHistory by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Random Test", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        when {
            active != null -> ActiveTestContent(active!!, onHint = viewModel::revealHint, onReveal = viewModel::revealAnswer, onAnswer = viewModel::answer)
            summary != null -> TestResultContent(summary!!, onNew = viewModel::startNewTest, onHistory = { if (onOpenHistory != null) onOpenHistory() else showHistory = true })
            else -> {
                Text("Choose words from", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                testSources.forEach { (value, label) ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        RadioButton(selected = source == value, onClick = { viewModel.selectSource(value) })
                        Text(label)
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = count, onValueChange = viewModel::setRequestedCount, label = { Text("Number of questions") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (message != null) { Spacer(Modifier.height(6.dp)); Text(message!!, color = MaterialTheme.colorScheme.error) }
                Spacer(Modifier.height(12.dp))
                Button(onClick = { viewModel.startTest() }, modifier = Modifier.fillMaxWidth()) { Text("Start Random Test") }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { if (onOpenHistory != null) onOpenHistory() else showHistory = true }, modifier = Modifier.fillMaxWidth()) { Text("Test History (${history.size})") }
            }
        }
    }

    if (showHistory) {
        AlertDialog(onDismissRequest = { showHistory = false }, title = { Text("Test History") },
            text = {
                if (history.isEmpty()) Text("No completed tests yet.") else LazyColumn {
                    items(history, key = { it.id }) { session ->
                        Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                            Text(formatDate(session.completedAt ?: session.startedAt), fontWeight = FontWeight.SemiBold)
                            Text("${sourceLabel(session.source)} • ${session.actualCount} questions • ${session.correctCount} correct • ${accuracy(session)}%")
                            TextButton(onClick = { viewModel.loadHistoryDetails(session) { historyDetails = it } }) { Text("View answers") }
                            Divider()
                        }
                    }
                }
            }, confirmButton = { TextButton(onClick = { showHistory = false }) { Text("Close") } })
    }
    historyDetails?.let { details ->
        AlertDialog(onDismissRequest = { historyDetails = null }, title = { Text("Test Details") },
            text = { LazyColumn { items(details.questions) { q ->
                Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Text(q.word.englishWord, fontWeight = FontWeight.Bold)
                    Text(if (q.result == "CORRECT") "Correct" else "Incorrect", color = if (q.result == "CORRECT") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                    Divider()
                }
            } } }, confirmButton = { TextButton(onClick = { historyDetails = null }) { Text("Close") } })
    }
}

@Composable
private fun ActiveTestContent(
    test: ActiveTest,
    onHint: () -> Unit,
    onReveal: () -> Unit,
    onAnswer: (Boolean) -> Unit
) {
    val q = test.current ?: return
    Text("Question ${test.position + 1} of ${test.questions.size}", style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(12.dp))
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(q.word.englishWord, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            if (test.hintVisible) {
                Divider()
                WordImage(imagePath = q.word.imagePath, word = q.word.englishWord)
                Text("Example: ${q.word.sentence1}")
                q.word.sentence2?.let { Text("Example 2: $it") }
            }
            if (test.answerVisible) {
                Divider()
                Text(q.word.englishMeaning, style = MaterialTheme.typography.titleMedium)
                Text(q.word.banglaMeaning, style = MaterialTheme.typography.titleLarge)
                q.word.partOfSpeech?.let { Text("Part of speech: $it") }
                q.word.synonym?.let { Text("Synonym: $it") }
                q.word.antonym?.let { Text("Antonym: $it") }
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    if (!test.hintVisible) {
        OutlinedButton(onClick = onHint, modifier = Modifier.fillMaxWidth()) { Text("Hint") }
        Spacer(Modifier.height(8.dp))
    }
    if (!test.answerVisible) {
        Button(onClick = onReveal, modifier = Modifier.fillMaxWidth()) { Text("Show Answer") }
    } else {
        Text("Did you know this word?", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = { onAnswer(false) }, modifier = Modifier.weight(1f)) { Text("Incorrect") }
            Button(onClick = { onAnswer(true) }, modifier = Modifier.weight(1f)) { Text("Correct") }
        }
    }
}

@Composable
private fun TestResultContent(summary: TestSummary, onNew: () -> Unit, onHistory: () -> Unit) {
    val s = summary.session
    val percent = accuracy(s)
    Text("Test Completed", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(14.dp))
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${s.correctCount} / ${s.actualCount} Correct", style = MaterialTheme.typography.headlineMedium)
            Text("Accuracy: $percent%", style = MaterialTheme.typography.titleLarge)
            Text("Incorrect: ${s.incorrectCount}")
            Text("Source: ${sourceLabel(s.source)}")
            Text("Completed: ${formatDate(s.completedAt ?: s.startedAt)}")
        }
    }
    Spacer(Modifier.height(12.dp))
    Button(onClick = onNew, modifier = Modifier.fillMaxWidth()) { Text("Start New Test") }
    OutlinedButton(onClick = onHistory, modifier = Modifier.fillMaxWidth()) { Text("Test History") }
    Spacer(Modifier.height(8.dp))
    Text("Question review", style = MaterialTheme.typography.titleMedium)
    Column {
        summary.questions.forEach { q ->
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(q.word.englishWord, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                Text(if (q.result == "CORRECT") "Correct" else "Incorrect", color = if (q.result == "CORRECT") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            }
            Divider()
        }
    }
}

private fun sourceLabel(source: String) = testSources.firstOrNull { it.first == source }?.second ?: source
private fun accuracy(session: TestSessionEntity): Int = if (session.actualCount == 0) 0 else (session.correctCount * 100f / session.actualCount).toInt()
private fun formatDate(timestamp: Long): String = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(timestamp))


@Composable
fun TestHistoryScreen(viewModel: RandomTestViewModel = viewModel()) {
    val history by viewModel.history.collectAsState()
    var selectedDetails by remember { mutableStateOf<TestSummary?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Completed Tests", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        if (history.isEmpty()) {
            Text("No completed tests yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(history, key = { it.id }) { session ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(14.dp)) {
                            Text(formatDate(session.completedAt ?: session.startedAt), fontWeight = FontWeight.SemiBold)
                            Text("${sourceLabel(session.source)} • ${session.actualCount} questions")
                            Text("${session.correctCount} correct • ${session.incorrectCount} incorrect • ${accuracy(session)}% accuracy")
                            TextButton(onClick = { viewModel.loadHistoryDetails(session) { selectedDetails = it } }) {
                                Text("View question details")
                            }
                        }
                    }
                }
            }
        }
    }

    selectedDetails?.let { details ->
        AlertDialog(
            onDismissRequest = { selectedDetails = null },
            title = { Text("Test Details") },
            text = {
                LazyColumn {
                    items(details.questions) { q ->
                        Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                            Text(q.word.englishWord, fontWeight = FontWeight.Bold)
                            Text(
                                if (q.result == "CORRECT") "Correct" else "Incorrect",
                                color = if (q.result == "CORRECT") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                            )
                            Divider()
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { selectedDetails = null }) { Text("Close") } }
        )
    }
}
