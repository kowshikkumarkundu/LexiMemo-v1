package com.leximemo.app.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "words", indices = [Index(value = ["normalizedWord"], unique = true), Index("englishWord"), Index("addedDate"), Index("latestRating")])
data class WordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val englishWord: String,
    val normalizedWord: String,
    val englishMeaning: String,
    val banglaMeaning: String,
    val sentence1: String,
    val sentence2: String? = null,
    val partOfSpeech: String? = null,
    val synonym: String? = null,
    val antonym: String? = null,
    val imagePath: String? = null,
    val addedDate: String,
    val isFavorite: Boolean = false,
    val latestRating: String? = null,
    val updatedAt: Long
)

@Entity(
    tableName = "revision_events",
    foreignKeys = [ForeignKey(entity = WordEntity::class, parentColumns = ["id"], childColumns = ["wordId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["wordId", "intervalDay"], unique = true), Index(value = ["id", "wordId"], unique = true), Index(value = ["scheduledDate", "isCompleted"]), Index(value = ["wordId", "isCompleted", "scheduledDate"])]
)
data class RevisionEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val wordId: Long,
    val intervalDay: Int,
    val scheduledDate: String,
    val isCompleted: Boolean = false,
    val completedAt: Long? = null,
    val createdAt: Long
)

@Entity(
    tableName = "review_history",
    foreignKeys = [ForeignKey(entity = RevisionEventEntity::class, parentColumns = ["id"], childColumns = ["revisionEventId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["revisionEventId"], unique = true)]
)
data class ReviewHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val revisionEventId: Long,
    val rating: String,
    val reviewedDate: String,
    val reviewedAt: Long
)

@Entity(tableName = "daily_activity")
data class DailyActivityEntity(
    @PrimaryKey val date: String,
    val addedWordCount: Int,
    val targetForDay: Int
)

@Entity(tableName = "test_sessions", indices = [Index("completedAt")])
data class TestSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val source: String,
    val requestedCount: Int,
    val actualCount: Int,
    val startedAt: Long,
    val completedAt: Long? = null,
    val correctCount: Int = 0,
    val incorrectCount: Int = 0
)

@Entity(
    tableName = "test_results",
    foreignKeys = [
        ForeignKey(entity = TestSessionEntity::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = WordEntity::class, parentColumns = ["id"], childColumns = ["wordId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index(value = ["sessionId", "wordId"], unique = true), Index(value = ["sessionId", "position"], unique = true), Index(value = ["wordId"])]
)
data class TestResultEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val wordId: Long,
    val position: Int,
    val result: String? = null
)

@Entity(tableName = "revision_sessions", indices = [Index("status")])
data class RevisionSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionDate: String,
    val createdAt: Long,
    val updatedAt: Long,
    val status: String,
    val completedAt: Long? = null,
    // ACTIVE rows use 1; completed rows use NULL. A unique index enforces one active session.
    val activeSlot: Int? = null
)

@Entity(
    tableName = "revision_session_items",
    foreignKeys = [
        ForeignKey(entity = RevisionSessionEntity::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = WordEntity::class, parentColumns = ["id"], childColumns = ["wordId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = RevisionEventEntity::class, parentColumns = ["id", "wordId"], childColumns = ["revisionEventId", "wordId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index(value = ["sessionId", "wordId"], unique = true), Index(value = ["revisionEventId"], unique = true), Index(value = ["sessionId", "position"], unique = true), Index(value = ["revisionEventId", "wordId"]), Index(value = ["wordId"])]
)
data class RevisionSessionItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val wordId: Long,
    val revisionEventId: Long,
    val position: Int,
    val addedAt: Long
)


data class UpcomingRevisionItem(
    val scheduledDate: String,
    val intervalDay: Int,
    val wordId: Long,
    val englishWord: String
)
