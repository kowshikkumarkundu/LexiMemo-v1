package com.leximemo.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.leximemo.app.presentation.navigation.LexiMemoNavigation
import com.leximemo.app.presentation.theme.LexiMemoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as LexiMemoApp
        setContent {
            val themeMode by app.preferences.themeMode.collectAsState(initial = "LIGHT")
            LexiMemoTheme(themeMode = themeMode) { LexiMemoNavigation() }
        }
    }
}
