package com.leximemo.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.leximemo.app.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface WordDao {
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(word: WordEntity): Long
    @Update suspend fun update(word: WordEntity)
    @Query("DELETE FROM words WHERE id = :id") suspend fun deleteById(id: Long)
    @Query("SELECT * FROM words ORDER BY addedDate DESC, id DESC") fun observeAll(): Flow<List<WordEntity>>
    @Query("SELECT * FROM words WHERE addedDate = :date ORDER BY id ASC") fun observeWordsAddedOn(date: String): Flow<List<WordEntity>>
    @Query("SELECT * FROM words WHERE id = :id LIMIT 1") suspend fun getById(id: Long): WordEntity?
    @Query("UPDATE words SET latestRating = :rating, updatedAt = :updatedAt WHERE id = :wordId") suspend fun updateLatestRating(wordId: Long, rating: String, updatedAt: Long)
    @Query("SELECT * FROM words WHERE normalizedWord = :normalized LIMIT 1") suspend fun findByNormalizedWord(normalized: String): WordEntity?
    @Query("SELECT COUNT(*) FROM words WHERE addedDate = :date") fun observeAddedCount(date: String): Flow<Int>
    @Query("UPDATE words SET isFavorite = :favorite, updatedAt = :updatedAt WHERE id = :wordId")
    suspend fun updateFavorite(wordId: Long, favorite: Boolean, updatedAt: Long)
}

@Dao
interface RevisionDao {
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertEvents(events: List<RevisionEventEntity>)
    @Query("SELECT * FROM revision_events WHERE scheduledDate <= :today AND isCompleted = 0 ORDER BY scheduledDate ASC, id ASC") suspend fun getPendingEvents(today: String): List<RevisionEventEntity>
    @Query("SELECT * FROM revision_events WHERE id = :id LIMIT 1") suspend fun getEventById(id: Long): RevisionEventEntity?
    @Query("SELECT * FROM revision_events WHERE wordId = :wordId AND scheduledDate <= :today AND isCompleted = 0 ORDER BY scheduledDate ASC, intervalDay ASC") suspend fun getPendingEventsForWord(wordId: Long, today: String): List<RevisionEventEntity>
    @Query("SELECT revision_events.scheduledDate AS scheduledDate, revision_events.intervalDay AS intervalDay, words.id AS wordId, words.englishWord AS englishWord FROM revision_events INNER JOIN words ON words.id = revision_events.wordId WHERE revision_events.scheduledDate >= :fromDate AND revision_events.scheduledDate <= :toDate AND revision_events.isCompleted = 0 ORDER BY revision_events.scheduledDate ASC, words.englishWord COLLATE NOCASE ASC") suspend fun getUpcomingRevisions(fromDate: String, toDate: String): List<UpcomingRevisionItem>
    @Query("UPDATE revision_events SET isCompleted = 1, completedAt = :completedAt WHERE id = :eventId AND isCompleted = 0") suspend fun completeEvent(eventId: Long, completedAt: Long): Int
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertReviewHistory(history: ReviewHistoryEntity)
    @Query("UPDATE revision_sessions SET status = :status, updatedAt = :updatedAt, completedAt = :completedAt WHERE id = :sessionId") suspend fun updateSessionStatus(sessionId: Long, status: String, updatedAt: Long, completedAt: Long?)
    @Query("SELECT COUNT(DISTINCT wordId) FROM revision_events WHERE scheduledDate <= :today AND isCompleted = 0") fun observePendingEventCount(today: String): Flow<Int>
    @Query("SELECT * FROM revision_sessions WHERE status = 'ACTIVE' LIMIT 1") suspend fun getActiveSession(): RevisionSessionEntity?
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertSession(session: RevisionSessionEntity): Long
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertSessionItems(items: List<RevisionSessionItemEntity>)
    @Query("SELECT * FROM revision_session_items WHERE sessionId = :sessionId ORDER BY position ASC") suspend fun getSessionItems(sessionId: Long): List<RevisionSessionItemEntity>
}

@Dao
interface DailyActivityDao {
    @Query("SELECT * FROM daily_activity WHERE date = :date LIMIT 1") suspend fun get(date: String): DailyActivityEntity?
    @Query("SELECT * FROM daily_activity WHERE date = :date LIMIT 1") fun observe(date: String): Flow<DailyActivityEntity?>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(activity: DailyActivityEntity)
    @Query("UPDATE daily_activity SET addedWordCount = CASE WHEN addedWordCount > 0 THEN addedWordCount - 1 ELSE 0 END WHERE date = :date")
    suspend fun decrementAddedCount(date: String)
    @Query("SELECT * FROM daily_activity ORDER BY date DESC") fun observeAll(): Flow<List<DailyActivityEntity>>
    @Query("SELECT COUNT(*) FROM words") fun observeTotalWordCount(): Flow<Int>
}

@Dao
interface TestDao {
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertSession(session: TestSessionEntity): Long
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertResults(results: List<TestResultEntity>)
    @Query("DELETE FROM test_sessions WHERE completedAt IS NULL") suspend fun discardIncompleteSessions()
    @Query("SELECT * FROM test_sessions WHERE completedAt IS NOT NULL ORDER BY completedAt DESC") fun observeHistory(): Flow<List<TestSessionEntity>>
    @Query("UPDATE test_results SET result = :result WHERE sessionId = :sessionId AND wordId = :wordId AND result IS NULL") suspend fun saveAnswer(sessionId: Long, wordId: Long, result: String): Int
    @Query("SELECT * FROM test_results WHERE sessionId = :sessionId ORDER BY position ASC") suspend fun getResults(sessionId: Long): List<TestResultEntity>
    @Query("SELECT * FROM test_sessions WHERE id = :sessionId LIMIT 1") suspend fun getSession(sessionId: Long): TestSessionEntity?
    @Query("UPDATE test_sessions SET correctCount = :correct, incorrectCount = :incorrect, completedAt = :completedAt WHERE id = :sessionId") suspend fun finishSession(sessionId: Long, correct: Int, incorrect: Int, completedAt: Long)
}
