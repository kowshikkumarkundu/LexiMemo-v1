package com.leximemo.app.data.backup

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.os.Build
import com.leximemo.app.data.local.LexiMemoDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Manual, local-only ZIP backup. No network or external service is used. */
object BackupRestoreManager {
    private const val FORMAT_VERSION = 1
    private const val DATABASE_SCHEMA_VERSION = 1
    private const val MAX_ARCHIVE_BYTES = 500L * 1024L * 1024L
    private const val DATABASE_ENTRY = "database/leximemo.db"
    private const val MANIFEST_ENTRY = "manifest.json"

    suspend fun createBackup(context: Context, destination: Uri) = withContext(Dispatchers.IO) {
        val work = File(context.cacheDir, "leximemo_backup_${System.nanoTime()}").apply { mkdirs() }
        try {
            val snapshot = File(work, "leximemo.db")
            val roomDb = LexiMemoDatabase.getInstance(context)
            val supportDb = roomDb.openHelper.writableDatabase
            var snapshotCreated = false
            if (Build.VERSION.SDK_INT >= 29) {
                try {
                    // VACUUM INTO produces a transactionally consistent snapshot, including committed WAL data.
                    val escaped = snapshot.absolutePath.replace("'", "''")
                    supportDb.execSQL("VACUUM INTO '$escaped'")
                    snapshotCreated = snapshot.isFile && snapshot.length() > 0L
                } catch (_: Exception) {
                    snapshot.delete()
                }
            }
            if (!snapshotCreated) {
                // Compatibility fallback for older SQLite builds: checkpoint WAL before copying the main file.
                supportDb.query("PRAGMA wal_checkpoint(TRUNCATE)").use { cursor ->
                    check(cursor.moveToFirst() && cursor.getInt(0) == 0) { "Database is busy. Please try the backup again." }
                }
                File(context.getDatabasePath("leximemo.db").absolutePath).copyTo(snapshot, overwrite = true)
            }
            check(snapshot.isFile && snapshot.length() > 0L) { "Could not create database snapshot." }

            val imageDir = File(context.filesDir, "word_images")
            val images = imageDir.listFiles()?.filter { it.isFile }.orEmpty()
            val imageManifest = JSONArray()
            images.forEach { image ->
                imageManifest.put(JSONObject().put("name", image.name).put("sha256", sha256(image)))
            }
            val manifest = JSONObject()
                .put("formatVersion", FORMAT_VERSION)
                .put("databaseSchemaVersion", DATABASE_SCHEMA_VERSION)
                .put("databaseSha256", sha256(snapshot))
                .put("createdAt", System.currentTimeMillis())
                .put("images", imageManifest)

            val archive = File(work, "LexiMemo-Backup.zip")
            ZipOutputStream(FileOutputStream(archive)).use { zip ->
                zip.putNextEntry(ZipEntry(DATABASE_ENTRY))
                snapshot.inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
                images.forEach { image ->
                    zip.putNextEntry(ZipEntry("word_images/${image.name}"))
                    image.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
                zip.putNextEntry(ZipEntry(MANIFEST_ENTRY))
                zip.write(manifest.toString().toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
            context.contentResolver.openOutputStream(destination, "w")?.use { output ->
                archive.inputStream().use { it.copyTo(output) }
            } ?: error("Unable to write the selected backup file.")
        } finally {
            work.deleteRecursively()
        }
    }

    suspend fun restoreBackup(context: Context, source: Uri) = withContext(Dispatchers.IO) {
        val work = File(context.cacheDir, "leximemo_restore_${System.nanoTime()}").apply { mkdirs() }
        val stagedImages = File(work, "word_images").apply { mkdirs() }
        val stagedDb = File(work, "leximemo.db")
        val archive = File(work, "incoming.zip")
        try {
            context.contentResolver.openInputStream(source)?.use { input ->
                FileOutputStream(archive).use { output ->
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                    var total = 0L
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        total += count
                        require(total <= MAX_ARCHIVE_BYTES) { "Backup file is too large." }
                        output.write(buffer, 0, count)
                    }
                }
            } ?: error("Unable to read the selected backup file.")

            var manifestText: String? = null
            var expanded = 0L
            ZipInputStream(FileInputStream(archive)).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    require(!entry.isDirectory) { "Unexpected directory in backup." }
                    val name = entry.name
                    require(!name.startsWith("/") && !name.contains("..") && !name.contains('\\')) { "Invalid backup entry." }
                    when {
                        name == MANIFEST_ENTRY -> {
                            val bytes = zip.readBytes()
                            require(bytes.size <= 1_000_000) { "Backup manifest is invalid." }
                            manifestText = bytes.toString(Charsets.UTF_8)
                        }
                        name == DATABASE_ENTRY -> {
                            FileOutputStream(stagedDb).use { out -> expanded += copyLimited(zip, out, MAX_ARCHIVE_BYTES - expanded) }
                        }
                        name.startsWith("word_images/") -> {
                            val filename = name.removePrefix("word_images/")
                            require(filename.isNotBlank() && !filename.contains('/')) { "Invalid image entry." }
                            val target = File(stagedImages, filename)
                            FileOutputStream(target).use { out -> expanded += copyLimited(zip, out, MAX_ARCHIVE_BYTES - expanded) }
                        }
                        else -> error("Unknown item in backup: $name")
                    }
                    require(expanded <= MAX_ARCHIVE_BYTES) { "Backup expands beyond the allowed size." }
                    zip.closeEntry()
                }
            }

            val manifest = JSONObject(manifestText ?: error("Backup manifest is missing."))
            require(manifest.getInt("formatVersion") == FORMAT_VERSION) { "Unsupported backup format." }
            require(manifest.getInt("databaseSchemaVersion") == DATABASE_SCHEMA_VERSION) { "Backup database version is not supported by this app." }
            require(stagedDb.isFile && sha256(stagedDb) == manifest.getString("databaseSha256")) { "Database checksum verification failed." }

            val expectedImages = manifest.getJSONArray("images")
            val expectedNames = mutableSetOf<String>()
            for (index in 0 until expectedImages.length()) {
                val item = expectedImages.getJSONObject(index)
                val name = item.getString("name")
                require(name.isNotBlank() && !name.contains('/') && !name.contains('\\') && name != "." && name != "..") { "Invalid image metadata." }
                val image = File(stagedImages, name)
                require(image.isFile && sha256(image) == item.getString("sha256")) { "Image checksum verification failed: $name" }
                expectedNames += name
            }
            require(stagedImages.listFiles().orEmpty().map { it.name }.toSet() == expectedNames) { "Backup image list does not match its manifest." }

            validateDatabase(stagedDb)

            // Keep a rollback copy until both the database and image directory have been installed.
            val liveDb = context.getDatabasePath("leximemo.db")
            val liveImages = File(context.filesDir, "word_images")
            val oldDb = File(work, "old-leximemo.db")
            val oldImages = File(work, "old-word_images")
            if (liveDb.exists()) liveDb.copyTo(oldDb, overwrite = true)
            if (liveImages.exists()) liveImages.copyRecursively(oldImages, overwrite = true)

            var databaseClosed = false
            val installDb = File(liveDb.parentFile, "leximemo.restore.tmp")
            val previousDb = File(liveDb.parentFile, "leximemo.previous.tmp")
            try {
                LexiMemoDatabase.closeInstance()
                databaseClosed = true
                // Remove stale WAL sidecars before swapping the database file.
                File(liveDb.absolutePath + "-wal").delete()
                File(liveDb.absolutePath + "-shm").delete()
                liveDb.parentFile?.mkdirs()
                stagedDb.copyTo(installDb, overwrite = true)
                if (liveDb.exists()) check(liveDb.renameTo(previousDb)) { "Could not stage the current database for rollback." }
                check(installDb.renameTo(liveDb)) { "Could not install the restored database." }

                val stagedImageInstall = File(context.filesDir, "word_images.restore.tmp")
                if (stagedImageInstall.exists()) stagedImageInstall.deleteRecursively()
                if (stagedImages.exists()) stagedImages.copyRecursively(stagedImageInstall, overwrite = true)
                if (liveImages.exists()) liveImages.deleteRecursively()
                if (stagedImageInstall.exists()) check(stagedImageInstall.renameTo(liveImages)) { "Could not install restored images." }

                validateDatabase(liveDb)
                // Re-open through Room before reporting success.
                LexiMemoDatabase.getInstance(context).openHelper.writableDatabase
                previousDb.delete()
            } catch (failure: Exception) {
                if (databaseClosed) LexiMemoDatabase.closeInstance()
                File(liveDb.absolutePath + "-wal").delete()
                File(liveDb.absolutePath + "-shm").delete()
                if (liveDb.exists()) liveDb.delete()
                if (previousDb.exists()) previousDb.renameTo(liveDb)
                else if (oldDb.exists()) oldDb.copyTo(liveDb, overwrite = true)
                if (liveImages.exists()) liveImages.deleteRecursively()
                if (oldImages.exists()) oldImages.copyRecursively(liveImages, overwrite = true)
                LexiMemoDatabase.getInstance(context).openHelper.writableDatabase
                throw IllegalStateException("Restore failed. Your previous data has been restored.", failure)
            } finally {
                installDb.delete()
                previousDb.delete()
            }
        } finally {
            work.deleteRecursively()
        }
    }

    private fun validateDatabase(file: File) {
        val db = SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
        try {
            db.rawQuery("PRAGMA integrity_check", null).use { cursor ->
                require(cursor.moveToFirst() && cursor.getString(0) == "ok") { "Database integrity check failed." }
            }
            db.rawQuery("PRAGMA foreign_key_check", null).use { cursor ->
                require(!cursor.moveToFirst()) { "Backup contains invalid database relationships." }
            }
            db.rawQuery("PRAGMA user_version", null).use { cursor ->
                require(cursor.moveToFirst() && cursor.getInt(0) == DATABASE_SCHEMA_VERSION) { "Unexpected database schema version." }
            }
        } finally {
            db.close()
        }
    }

    private fun copyLimited(input: java.io.InputStream, output: java.io.OutputStream, remaining: Long): Long {
        require(remaining > 0L) { "Backup expands beyond the allowed size." }
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
        var total = 0L
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            require(total <= remaining) { "Backup expands beyond the allowed size." }
            output.write(buffer, 0, count)
        }
        return total
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
