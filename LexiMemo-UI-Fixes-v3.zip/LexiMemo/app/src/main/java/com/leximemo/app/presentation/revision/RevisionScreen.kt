package com.leximemo.app.presentation.revision

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.leximemo.app.data.repository.RevisionCard
import com.leximemo.app.presentation.components.WordImage

@Composable
fun RevisionScreen() {
    val context = LocalContext.current
    val vm: RevisionViewModel = viewModel(factory = object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            RevisionViewModel(context.applicationContext as android.app.Application) as T
    })
    val state by vm.state.collectAsState()
    val loading by vm.loading.collectAsState()
    val message by vm.message.collectAsState()
    val upcoming by vm.upcoming.collectAsState()
    var previewExpanded by remember { mutableStateOf(false) }
    var selectedPreviewDate by remember { mutableStateOf<String?>(LocalDate.now().plusDays(1).toString()) }
    val previewDates = (1L..5L).map { LocalDate.now().plusDays(it) }
    val groupedUpcoming = upcoming.groupBy { it.scheduledDate }
    val selectedUpcoming = selectedPreviewDate?.let { groupedUpcoming[it].orEmpty() }.orEmpty()
    val pending = state.cards.filter { !it.event.isCompleted }
    val completed = state.cards.size - pending.size
    var revealed by remember(state.sessionId) { mutableStateOf(false) }
    var hint by remember(state.sessionId) { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Today's Revision", style = MaterialTheme.typography.headlineMedium)
        Text("Review words that are due. Your progress is saved automatically.", style = MaterialTheme.typography.bodyLarge)
        if (loading) { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        else if (state.sessionId == null || state.cards.isEmpty()) {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("All caught up!", style = MaterialTheme.typography.titleLarge)
                Text("There are no words due for revision today.")
                OutlinedButton(onClick = vm::refresh) { Text("Refresh") }
            } }
        } else if (pending.isEmpty()) {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Revision completed!", style = MaterialTheme.typography.headlineSmall)
                Text("You reviewed ${state.cards.size} words in this session.")
                Text("Your next due words will appear when their scheduled date arrives.")
                Button(onClick = vm::refresh) { Text("Check Again") }
            } }
        } else {
            val card = pending.first()
            Text("${completed + 1} of ${state.cards.size}  •  $completed completed", style = MaterialTheme.typography.titleMedium)
            LinearProgressIndicator(progress = { completed.toFloat() / state.cards.size.coerceAtLeast(1) }, modifier = Modifier.fillMaxWidth())
            RevisionFlashcard(card = card, hint = hint, revealed = revealed)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { hint = !hint }, modifier = Modifier.weight(1f)) { Text(if (hint) "Hide Hint" else "Hint") }
                Button(onClick = { revealed = true }, modifier = Modifier.weight(1f)) { Text(if (revealed) "Answer Shown" else "Show Answer") }
            }
            if (revealed) {
                Text("How well did you remember?", style = MaterialTheme.typography.titleMedium)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.rate(card, "MEMORIZED"); revealed = false; hint = false }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)) { Text("Memorized") }
                    Button(onClick = { vm.rate(card, "HINT_NEEDED"); revealed = false; hint = false }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)) { Text("Hint Needed") }
                }
                OutlinedButton(onClick = { vm.rate(card, "FORGOT"); revealed = false; hint = false }, modifier = Modifier.fillMaxWidth()) { Text("Forgot") }
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text("Upcoming Revisions", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    TextButton(onClick = { vm.refresh() }) { Text("Refresh") }
                }
                Box {
                    OutlinedButton(onClick = { previewExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                        val selectedDate = selectedPreviewDate?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
                        Text(if (selectedDate == null) "None • 0 words  ▾" else
                            "${selectedDate.format(DateTimeFormatter.ofPattern("EEE, d MMM", Locale.ENGLISH))} • ${selectedUpcoming.map { it.wordId }.distinct().size} words  ▾")
                    }
                    DropdownMenu(expanded = previewExpanded, onDismissRequest = { previewExpanded = false }) {
                        DropdownMenuItem(
                            text = { Text("None • Hide word list") },
                            onClick = { selectedPreviewDate = null; previewExpanded = false }
                        )
                        previewDates.forEach { date ->
                            val dateKey = date.toString()
                            val count = groupedUpcoming[dateKey].orEmpty().map { it.wordId }.distinct().size
                            DropdownMenuItem(
                                text = { Text("${date.format(DateTimeFormatter.ofPattern("EEEE, d MMM", Locale.ENGLISH))} • $count ${if (count == 1) "word" else "words"}") },
                                onClick = { selectedPreviewDate = dateKey; previewExpanded = false }
                            )
                        }
                    }
                }
                if (selectedUpcoming.isEmpty()) {
                    Text("No words scheduled for this day.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    selectedUpcoming.distinctBy { it.wordId }.forEach { item ->
                        Text("• ${item.englishWord}", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
        message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}

@Composable
private fun RevisionFlashcard(card: RevisionCard, hint: Boolean, revealed: Boolean) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (hint) {
                WordImage(imagePath = card.word.imagePath, word = card.word.englishWord)
            }
            Text(card.word.englishWord, style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
            card.word.partOfSpeech?.let { Text(it, style = MaterialTheme.typography.labelLarge) }
            if (hint) {
                Text("Hint", style = MaterialTheme.typography.titleMedium)
                Text(card.word.sentence1, style = MaterialTheme.typography.bodyLarge)
                card.word.sentence2?.let { Text(it, style = MaterialTheme.typography.bodyLarge) }
            }
            if (revealed) {
                HorizontalDivider()
                Text("English Meaning", style = MaterialTheme.typography.titleSmall)
                Text(card.word.englishMeaning, style = MaterialTheme.typography.bodyLarge)
                Text("বাংলা অর্থ", style = MaterialTheme.typography.titleSmall)
                Text(card.word.banglaMeaning, style = MaterialTheme.typography.bodyLarge)
                card.word.synonym?.let { Text("Synonyms: $it", style = MaterialTheme.typography.bodyMedium) }
                card.word.antonym?.let { Text("Antonyms: $it", style = MaterialTheme.typography.bodyMedium) }
                Text("Example", style = MaterialTheme.typography.titleSmall)
                Text(card.word.sentence1, style = MaterialTheme.typography.bodyLarge)
                card.word.sentence2?.let { Text(it, style = MaterialTheme.typography.bodyLarge) }
            }
        }
    }
}
