package com.leximemo.app.data.image

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

object WordImageStorage {
    const val MAX_IMAGE_BYTES = 5L * 1024L * 1024L

    /** Copies a selected image into app-private storage; the original provider URI is never retained. */
    fun importImage(context: Context, uri: Uri): String {
        val directory = File(context.filesDir, "word_images").apply { mkdirs() }
        val destination = File(directory, "word_${System.currentTimeMillis()}_${(1000..9999).random()}.img")
        var total = 0L
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destination).use { output ->
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        total += read
                        require(total <= MAX_IMAGE_BYTES) { "Image must be 5 MB or smaller." }
                        output.write(buffer, 0, read)
                    }
                    output.flush()
                }
            } ?: throw IllegalArgumentException("Unable to open the selected image.")
            require(total > 0L) { "Selected image is empty." }
            return destination.absolutePath
        } catch (error: Exception) {
            destination.delete()
            throw error
        }
    }

    fun deleteIfOwned(path: String?) {
        if (path.isNullOrBlank()) return
        val file = File(path)
        if (file.parentFile?.name == "word_images") file.delete()
    }
}
