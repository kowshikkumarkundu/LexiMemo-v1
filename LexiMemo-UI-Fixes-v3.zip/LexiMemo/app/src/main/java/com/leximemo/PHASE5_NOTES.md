# Phase 5 — Revision Engine

- Due revision events are selected from the fixed 1, 3, 7, 15, 30 day schedule already created when a word is saved.
- Overdue events remain due (`scheduledDate <= today`) and are carried forward without changing their scheduled dates.
- A persistent ACTIVE revision session is reused after leaving/restarting the app.
- A session includes each due word at most once, selecting that word's earliest pending event.
- Hint reveals example sentences only; Show Answer reveals meanings and details.
- Memorized, Hint Needed, and Forgot each complete exactly the current session event and create one review-history row.
- Latest rating is updated on the word; ratings do not reschedule other events.
- Once all session items are rated, the session is marked COMPLETED. Remaining overdue events for a word can appear in a later session.
- Room schema is unchanged (version 1); existing user data is retained.

## Validation
Source-level checks and ZIP integrity performed. Android Gradle compilation must be confirmed with GitHub Actions.
