package com.leximemo.app.presentation.practice

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.leximemo.app.LexiMemoApp
import com.leximemo.app.data.local.entity.WordEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import java.time.LocalDate

class PracticeViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as LexiMemoApp
    val practiceDate: String = LocalDate.now().toString()

    val todayWords: StateFlow<List<WordEntity>> = app.database.wordDao()
        .observeWordsAddedOn(practiceDate)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
}
