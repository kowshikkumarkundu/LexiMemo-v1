package com.leximemo.app.presentation.dashboard

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.leximemo.app.LexiMemoApp
import com.leximemo.app.data.local.entity.DailyActivityEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class DashboardViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as LexiMemoApp
    val today: LocalDate = LocalDate.now()
    val activity = app.database.dailyActivityDao().observe(today.toString())
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    val activities = app.database.dailyActivityDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val target = app.preferences.defaultDailyTarget
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 5)
    val totalWords = app.database.dailyActivityDao().observeTotalWordCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)
    val dueWords = app.database.revisionDao().observePendingEventCount(today.toString())
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    fun updateTarget(value: Int) {
        if (value !in 1..100) return
        viewModelScope.launch { app.preferences.setDefaultDailyTarget(value) }
    }

    fun currentStreak(rows: List<DailyActivityEntity>, today: LocalDate = LocalDate.now(), currentTarget: Int = 5): Int {
        val completedDates = rows.asSequence()
            .filter { row ->
                val effectiveTarget = if (row.date == today.toString()) currentTarget else row.targetForDay
                effectiveTarget > 0 && row.addedWordCount >= effectiveTarget
            }
            .mapNotNull { runCatching { LocalDate.parse(it.date) }.getOrNull() }
            .filter { !it.isAfter(today) }
            .toSet()

        var cursor = today
        var successfulDays = 0
        var graceDaysUsed = 0
        while (true) {
            if (cursor in completedDates) {
                successfulDays++
            } else {
                graceDaysUsed++
                if (graceDaysUsed > 1) break
            }
            cursor = cursor.minusDays(1)
        }
        return successfulDays
    }
}
