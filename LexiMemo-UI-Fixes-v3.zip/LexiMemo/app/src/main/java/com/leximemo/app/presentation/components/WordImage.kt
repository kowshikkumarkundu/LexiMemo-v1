package com.leximemo.app.presentation.components

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Displays a word's locally stored image. Tapping a real image opens a large preview. */
@Composable
fun WordImage(imagePath: String?, word: String, modifier: Modifier = Modifier) {
    var bitmap by remember(imagePath) { mutableStateOf<Bitmap?>(null) }
    var showPreview by remember(imagePath) { mutableStateOf(false) }

    LaunchedEffect(imagePath) {
        bitmap = withContext(Dispatchers.IO) {
            imagePath?.takeIf { it.isNotBlank() }?.let { path ->
                runCatching {
                    val file = java.io.File(path)
                    if (!file.isFile) return@runCatching null
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeFile(path, bounds)
                    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@runCatching null
                    var sample = 1
                    while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
                    BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
                }.getOrNull()
            }
        }
    }

    if (bitmap != null) {
        Image(
            bitmap = bitmap!!.asImageBitmap(),
            contentDescription = "Tap to enlarge image for $word",
            modifier = modifier
                .fillMaxWidth()
                .heightIn(max = 220.dp)
                .clickable { showPreview = true },
            contentScale = ContentScale.Fit
        )
    } else {
        Surface(
            modifier = modifier.heightIn(min = 76.dp, max = 100.dp),
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(10.dp)) {
                Icon(Icons.Default.Image, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    "No image",
                    modifier = Modifier.align(Alignment.BottomCenter),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    if (showPreview && bitmap != null) {
        Dialog(onDismissRequest = { showPreview = false }) {
            Surface(
                modifier = Modifier.fillMaxWidth().heightIn(min = 260.dp, max = 620.dp),
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface
            ) {
                androidx.compose.foundation.layout.Column(Modifier.fillMaxSize().padding(10.dp)) {
                    androidx.compose.foundation.layout.Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(word, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                        IconButton(onClick = { showPreview = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close image preview")
                        }
                    }
                    Image(
                        bitmap = bitmap!!.asImageBitmap(),
                        contentDescription = "Enlarged image for $word",
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        contentScale = ContentScale.Fit
                    )
                }
            }
        }
    }
}
