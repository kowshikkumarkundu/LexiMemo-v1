package com.leximemo.app.data.repository

import android.database.sqlite.SQLiteConstraintException
import androidx.room.withTransaction
import com.leximemo.app.data.image.WordImageStorage
import com.leximemo.app.data.local.LexiMemoDatabase
import com.leximemo.app.data.local.entity.DailyActivityEntity
import com.leximemo.app.data.local.entity.RevisionEventEntity
import com.leximemo.app.data.local.entity.WordEntity
import java.time.LocalDate
import java.util.Locale

sealed interface SaveWordResult {
    data class Saved(val id: Long) : SaveWordResult
    data object Duplicate : SaveWordResult
    data class Failed(val message: String) : SaveWordResult
}

class WordRepository(private val database: LexiMemoDatabase) {
    val words = database.wordDao().observeAll()

    suspend fun saveWord(
        englishWord: String,
        englishMeaning: String,
        banglaMeaning: String,
        sentence1: String,
        sentence2: String?,
        partOfSpeech: String?,
        synonym: String?,
        antonym: String?,
        imagePath: String?,
        dailyTarget: Int
    ): SaveWordResult {
        val cleanWord = englishWord.trim()
        val today = LocalDate.now()
        val normalized = cleanWord.lowercase(Locale.ROOT)
        val now = System.currentTimeMillis()
        return try {
            val id = database.withTransaction {
                if (database.wordDao().findByNormalizedWord(normalized) != null) return@withTransaction -1L
                val wordId = database.wordDao().insert(
                    WordEntity(
                        englishWord = cleanWord,
                        normalizedWord = normalized,
                        englishMeaning = englishMeaning.trim(),
                        banglaMeaning = banglaMeaning.trim(),
                        sentence1 = sentence1.trim(),
                        sentence2 = sentence2?.trim()?.takeIf(String::isNotEmpty),
                        partOfSpeech = partOfSpeech?.trim()?.takeIf(String::isNotEmpty),
                        synonym = synonym?.trim()?.takeIf(String::isNotEmpty),
                        antonym = antonym?.trim()?.takeIf(String::isNotEmpty),
                        imagePath = imagePath,
                        addedDate = today.toString(),
                        updatedAt = now
                    )
                )
                val intervals = listOf(1, 3, 7, 15, 30)
                database.revisionDao().insertEvents(intervals.map { day ->
                    RevisionEventEntity(
                        wordId = wordId,
                        intervalDay = day,
                        scheduledDate = today.plusDays(day.toLong()).toString(),
                        createdAt = now
                    )
                })
                val previous = database.dailyActivityDao().get(today.toString())
                val count = (previous?.addedWordCount ?: 0) + 1
                database.dailyActivityDao().upsert(
                    DailyActivityEntity(today.toString(), count, previous?.targetForDay ?: dailyTarget)
                )
                wordId
            }
            if (id == -1L) SaveWordResult.Duplicate else SaveWordResult.Saved(id)
        } catch (_: SQLiteConstraintException) {
            SaveWordResult.Duplicate
        } catch (error: Exception) {
            SaveWordResult.Failed(error.message ?: "Could not save this word.")
        }
    }


    suspend fun updateWord(
        existing: WordEntity,
        englishWord: String,
        englishMeaning: String,
        banglaMeaning: String,
        sentence1: String,
        sentence2: String?,
        partOfSpeech: String?,
        synonym: String?,
        antonym: String?,
        imagePath: String?
    ): SaveWordResult {
        val cleanWord = englishWord.trim()
        val normalized = cleanWord.lowercase(Locale.ROOT)
        return try {
            database.withTransaction {
                val duplicate = database.wordDao().findByNormalizedWord(normalized)
                if (duplicate != null && duplicate.id != existing.id) return@withTransaction false
                database.wordDao().update(
                    existing.copy(
                        englishWord = cleanWord,
                        normalizedWord = normalized,
                        englishMeaning = englishMeaning.trim(),
                        banglaMeaning = banglaMeaning.trim(),
                        sentence1 = sentence1.trim(),
                        sentence2 = sentence2?.trim()?.takeIf(String::isNotEmpty),
                        partOfSpeech = partOfSpeech?.trim()?.takeIf(String::isNotEmpty),
                        synonym = synonym?.trim()?.takeIf(String::isNotEmpty),
                        antonym = antonym?.trim()?.takeIf(String::isNotEmpty),
                        imagePath = imagePath,
                        updatedAt = System.currentTimeMillis()
                    )
                )
                true
            }.let { if (it) SaveWordResult.Saved(existing.id) else SaveWordResult.Duplicate }
        } catch (_: SQLiteConstraintException) {
            SaveWordResult.Duplicate
        } catch (error: Exception) {
            SaveWordResult.Failed(error.message ?: "Could not update this word.")
        }
    }

    suspend fun deleteWord(word: WordEntity) {
        database.withTransaction {
            database.wordDao().deleteById(word.id)
            database.dailyActivityDao().decrementAddedCount(word.addedDate)
        }
        WordImageStorage.deleteIfOwned(word.imagePath)
    }
}
