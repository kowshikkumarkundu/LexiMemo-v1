package com.leximemo.app.presentation.dictionary

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.leximemo.app.LexiMemoApp
import com.leximemo.app.data.local.entity.WordEntity
import com.leximemo.app.data.repository.WordRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DictionaryViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as LexiMemoApp
    private val repository = WordRepository(app.database)

    val words: StateFlow<List<WordEntity>> = repository.words
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun toggleFavorite(word: WordEntity) {
        viewModelScope.launch {
            app.database.wordDao().updateFavorite(
                word.id, !word.isFavorite, System.currentTimeMillis()
            )
        }
    }

    fun deleteWord(word: WordEntity, onDone: () -> Unit) {
        viewModelScope.launch {
            runCatching { repository.deleteWord(word) }
            onDone()
        }
    }
}
