package com.leximemo.app.presentation.revision

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.leximemo.app.LexiMemoApp
import com.leximemo.app.data.repository.RevisionCard
import com.leximemo.app.data.repository.RevisionRepository
import com.leximemo.app.data.repository.RevisionSessionState
import com.leximemo.app.data.local.entity.UpcomingRevisionItem
import java.time.LocalDate
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class RevisionViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = RevisionRepository((application as LexiMemoApp).database)
    private val _state = MutableStateFlow(RevisionSessionState(null, emptyList()))
    val state: StateFlow<RevisionSessionState> = _state.asStateFlow()
    private val _upcoming = MutableStateFlow<List<UpcomingRevisionItem>>(emptyList())
    val upcoming: StateFlow<List<UpcomingRevisionItem>> = _upcoming.asStateFlow()
    private val _loading = MutableStateFlow(true)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    init { refresh() }
    fun refresh() { viewModelScope.launch {
        _loading.value = true
        runCatching { repository.loadOrCreateSession() }
            .onSuccess { _state.value = it }
            .onFailure { _message.value = it.message ?: "Could not load revision session." }
        runCatching { repository.upcomingRevisions() }
            .onSuccess { _upcoming.value = it }
            .onFailure { _message.value = it.message ?: "Could not load upcoming revisions." }
        _loading.value = false
    } }

    fun rate(card: RevisionCard, rating: String) {
        val sessionId = _state.value.sessionId ?: return
        viewModelScope.launch {
            runCatching { repository.rate(sessionId, card, rating) }
                .onSuccess { refresh() }
                .onFailure { _message.value = it.message ?: "Could not save rating." }
        }
    }
}
