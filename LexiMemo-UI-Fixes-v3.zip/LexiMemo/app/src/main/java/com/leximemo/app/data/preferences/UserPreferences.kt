package com.leximemo.app.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "leximemo_preferences")

class UserPreferences(private val context: Context) {
    private val targetKey = intPreferencesKey("default_daily_target")
    private val themeKey = stringPreferencesKey("theme_mode")

    val defaultDailyTarget = context.dataStore.data.map { it[targetKey] ?: 5 }
    val themeMode = context.dataStore.data.map { it[themeKey] ?: "LIGHT" }

    suspend fun setDefaultDailyTarget(value: Int) {
        require(value > 0)
        context.dataStore.edit { it[targetKey] = value }
    }

    suspend fun setThemeMode(value: String) {
        require(value in setOf("LIGHT", "DARK", "SYSTEM"))
        context.dataStore.edit { it[themeKey] = value }
    }
}
