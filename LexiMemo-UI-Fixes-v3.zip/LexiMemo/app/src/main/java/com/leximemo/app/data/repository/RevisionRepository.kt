package com.leximemo.app.data.repository

import androidx.room.withTransaction
import com.leximemo.app.data.local.LexiMemoDatabase
import com.leximemo.app.data.local.entity.ReviewHistoryEntity
import com.leximemo.app.data.local.entity.RevisionSessionEntity
import com.leximemo.app.data.local.entity.RevisionSessionItemEntity
import com.leximemo.app.data.local.entity.WordEntity
import com.leximemo.app.data.local.entity.RevisionEventEntity
import java.time.LocalDate

data class RevisionCard(
    val word: WordEntity,
    val event: RevisionEventEntity,
    val events: List<RevisionEventEntity> = listOf(event)
)
data class RevisionSessionState(val sessionId: Long?, val cards: List<RevisionCard>)

class RevisionRepository(private val db: LexiMemoDatabase) {
    suspend fun loadOrCreateSession(today: LocalDate = LocalDate.now()): RevisionSessionState = db.withTransaction {
        val dao = db.revisionDao()
        val pending = dao.getPendingEvents(today.toString())
        var session = dao.getActiveSession()
        if (pending.isEmpty() && session == null) return@withTransaction RevisionSessionState(null, emptyList())

        val now = System.currentTimeMillis()
        if (session == null) {
            val sessionId = dao.insertSession(RevisionSessionEntity(
                sessionDate = today.toString(), createdAt = now, updatedAt = now,
                status = "ACTIVE", activeSlot = 1
            ))
            session = dao.getActiveSession()
            val selectedByWord = pending.distinctBy { it.wordId }
            if (selectedByWord.isNotEmpty()) {
                dao.insertSessionItems(selectedByWord.mapIndexed { index, event ->
                    RevisionSessionItemEntity(sessionId = sessionId, wordId = event.wordId,
                        revisionEventId = event.id, position = index, addedAt = now)
                })
            }
        } else {
            // Keep an unfinished session, but append any newly-due words so it never hides later arrivals.
            val existingWordIds = dao.getSessionItems(session.id).map { it.wordId }.toSet()
            val newWords = pending.filter { it.wordId !in existingWordIds }.distinctBy { it.wordId }
            if (newWords.isNotEmpty()) {
                val positionStart = dao.getSessionItems(session.id).size
                dao.insertSessionItems(newWords.mapIndexed { index, event ->
                    RevisionSessionItemEntity(sessionId = session.id, wordId = event.wordId,
                        revisionEventId = event.id, position = positionStart + index, addedAt = now)
                })
            }
        }

        val active = session ?: return@withTransaction RevisionSessionState(null, emptyList())
        val items = dao.getSessionItems(active.id)
        val cards = items.mapNotNull { item ->
            val dueEvents = dao.getPendingEventsForWord(item.wordId, today.toString())
            val sessionEvent = dao.getEventById(item.revisionEventId)
            val word = db.wordDao().getById(item.wordId)
            val displayEvent = dueEvents.firstOrNull() ?: sessionEvent
            if (displayEvent != null && word != null) RevisionCard(word, displayEvent, dueEvents) else null
        }
        if (cards.none { !it.event.isCompleted }) {
            dao.updateSessionStatus(active.id, "COMPLETED", now, now)
        }
        RevisionSessionState(active.id, cards)
    }

    suspend fun upcomingRevisions(today: LocalDate = LocalDate.now()) =
        db.revisionDao().getUpcomingRevisions(today.plusDays(1).toString(), today.plusDays(5).toString())

    suspend fun rate(sessionId: Long, card: RevisionCard, rating: String) = db.withTransaction {
        require(rating in setOf("MEMORIZED", "HINT_NEEDED", "FORGOT"))
        val now = System.currentTimeMillis()
        var changedAny = false
        card.events.forEach { dueEvent ->
            val changed = db.revisionDao().completeEvent(dueEvent.id, now)
            if (changed > 0) {
                changedAny = true
                db.revisionDao().insertReviewHistory(ReviewHistoryEntity(
                    revisionEventId = dueEvent.id, rating = rating,
                    reviewedDate = LocalDate.now().toString(), reviewedAt = now
                ))
            }
        }
        if (!changedAny) return@withTransaction
        db.wordDao().updateLatestRating(card.word.id, rating, now)
        val remaining = db.revisionDao().getSessionItems(sessionId)
            .count { item -> db.revisionDao().getPendingEventsForWord(item.wordId, LocalDate.now().toString()).isNotEmpty() }
        if (remaining == 0) db.revisionDao().updateSessionStatus(sessionId, "COMPLETED", now, now)
        else db.revisionDao().updateSessionStatus(sessionId, "ACTIVE", now, null)
    }
}
