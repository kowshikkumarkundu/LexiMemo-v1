# Phase 4 UI and Image Bug Fix

## Changes
- The flashcard front now shows the English word only; the word image is hidden initially.
- Hint reveals the saved image and example sentence(s) together.
- Tapping the image opens a full-screen dialog with pinch-to-zoom and drag-to-pan support.
- Hint and Show Answer controls are compact and displayed side by side.
- The whole practice screen is vertically scrollable, including on shorter displays.
- Removed the fixed-height nested LazyColumn from the flashcard to avoid nested scrolling and clipped content.
- Increased supporting text sizes slightly and reduced button padding/card spacing.
- Organized the answer side with a prominent word heading, optional part of speech, separated meaning/detail sections, and example sentences.
- Practice behavior remains unchanged: it only tracks viewed cards in the current screen session and does not update revision ratings, schedules, daily target, or streak.

## Validation
- ZIP archive integrity checked.
- Source-level checks performed for hidden initial image, hint-gated image/sentences, side-by-side actions, vertical scrolling, and zoomable image dialog.
- Android Gradle compilation was not run in this environment; build with the repository's GitHub Actions workflow.
