# Phase 4 — Today's Practice

## Included
- Practice shows only words whose `addedDate` is the device-local current date.
- The word list is observed from Room and updates when today's words are added or deleted.
- Flashcards show the English word and optional image/part of speech.
- Hint reveals example sentence(s) without revealing meanings.
- Show Answer reveals English meaning, Bangla meaning, optional synonyms/antonyms, and example sentences.
- Previous/Next navigation is bounded; it does not loop around.
- A card is counted as viewed when its answer is revealed. Completion is shown automatically after every current word has been revealed.
- Practice Again resets the in-memory session and allows unlimited repeats.
- Leaving/restarting the screen or process resets the session to the first card.

## Isolation guarantees
- No revision event, revision session, or review history is read or changed by Practice.
- No ratings are submitted and no Memorized/Hint Needed/Forgot collection status is changed.
- Daily target, daily activity, and streak data are not modified.
- No Practice History/session records are created.

## Verification
Source-level checks and ZIP integrity are performed when packaging. Android compilation must be verified by the repository's GitHub Actions workflow.
