# Phase 9 – Requested Corrections

- Added an adaptive launcher icon for LexiMemo (purple book-and-star mark).
- Dashboard daily target now reads the live DataStore preference, so a saved change updates the target immediately. Today's streak calculation uses that same live target.
- Dictionary search now includes sentence 1/2 and comma-separated synonym/antonym values, in addition to the existing word and meaning fields.
- Removed the Saved Words list from the Add Word screen. Existing words remain available in Dictionary and can still be edited there.
- Removed word images and definitions from Random Test result/history detail lists; the active test Hint still displays the sentence and image.
- Kept each new word's existing 1/3/7/15/30-day schedule relative to that word's own added date. Revision cards now group all due events for a word and mark all same-day due events together. An unfinished active session also appends newly-due words rather than hiding them.
- Added a compact Upcoming Revisions dropdown for the next five calendar days, with weekday/date, distinct word count, and the scheduled word list.

No Room entity or database schema version changes were made.
