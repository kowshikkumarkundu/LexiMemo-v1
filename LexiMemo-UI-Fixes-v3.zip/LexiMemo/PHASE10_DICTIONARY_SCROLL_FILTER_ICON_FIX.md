# Dictionary Scroll & App Icon Fix

- Kept the dictionary search field and result/sort header outside the scrolling word list, so they remain visible while words scroll.
- Removed the always-visible filter chips from the Dictionary content.
- Added All, Memorized, Hint Needed, Forgot, and Favorites as filter entries in the navigation drawer when the Dictionary screen is active.
- Replaced the launcher foreground artwork with a simple white W on the existing purple adaptive-icon background.
- Left word cards, sorting, favorites behavior, bottom navigation, and other screens unchanged.

Build verification: not run in this environment because the supplied project archive does not include the Gradle wrapper launcher script and no system Gradle executable is available.
