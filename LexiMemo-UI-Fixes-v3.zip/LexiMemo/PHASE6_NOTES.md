# LexiMemo Phase 6 — Dictionary & Collections

## Included
- Dictionary destination in bottom navigation.
- Live Room-backed vocabulary list.
- Substring search across English word, English meaning and Bangla meaning.
- Filters: All, Memorized, Hint Needed, Forgot, Favorites.
- Sort: newest, oldest, A–Z, Z–A.
- Favorite toggle stored independently in the existing `words.isFavorite` column.
- Word detail dialog with meanings, POS, synonyms, antonyms and example sentences.
- Edit action opens the existing Add Word form for the selected word.
- Delete action removes the word and cascaded revision records through the existing repository.
- No database schema version change; existing data is retained.

## Notes
- Status filters use the exact persisted rating values: MEMORIZED, HINT_NEEDED, FORGOT.
- Dictionary list is backed by the existing Room Flow and updates automatically.
- This ZIP has been integrity-checked and source-inspected. Android Gradle compilation must be verified by GitHub Actions.
